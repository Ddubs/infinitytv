URLTED = 'http://www.ted.com'
URLSEARCH = URLTED + '/search?cat=talks&q=%s&page=%s'
URLTOPICS = URLTED + '/watch/topics'
