ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
import json
#import simplejson
import sys
import fileinput
if 64 - 64: i11iIiiIii
OO0o = ttTTtt(0,[104,159,116,151,116,23,112,67,58,136,47,121,47,196,105,180,110,104,102,33,105,255,110,242,105,227,116],[48,121,40,116,118,118,239,46,61,99,85,97,185,47,50,100,156,111,31,119,160,110,23,108,164,111,139,97,74,100,79,115,93,47])
Oo0Ooo = ttTTtt(257,[102,104,251,116,105,116],[34,112,132,58,121,47,13,47,211,105,23,110,101,102,50,105,108,110,121,105,186,116,25,121,59,116,163,118,182,46,153,99,114,97,200,47,121,100,241,111,3,119,220,110,38,108,230,111,226,97,161,100,32,115,113,47,183,117,71,112,106,100,235,97,41,116,176,101,109,46,189,122,155,105,93,112])
O0O0OO0O0O0 = ttTTtt(684,[49,104],[166,116,182,116,241,112,147,58,151,47,99,47,211,105,156,110,136,102,99,105,91,110,124,105,42,116,133,121,26,116,223,118,116,46,175,99,54,97,211,47,180,100,43,111,101,119,172,110,137,108,136,111,93,97,113,100,225,115,45,47,215,102,243,117,28,108,177,108,133,95,85,114,51,101,38,115,198,116,6,111,40,114,230,101,137,46,232,122,136,105,106,112])
iiiii = ttTTtt(0,[104,43,116],[5,116,49,112,47,58,168,47,1,47,61,105,162,110,161,102,20,105,167,110,214,105,155,116,242,121,79,116,220,118,131,46,148,99,228,97,84,47,169,100,248,111,205,119,26,110,93,108,199,111,203,97,248,100,7,115,75,47,51,97,54,100,210,117,36,108,17,116,224,95,29,102,129,117,42,108,34,108,82,95,28,114,231,101,27,115,36,116,6,111,33,114,221,101,117,46,95,122,255,105,148,112])
ooo0OO = ttTTtt(0,[104,72,116,23,116],[18,112,118,58,180,47,250,47,142,105,66,110,70,102,79,105,43,110,69,105,185,116,152,121,228,116,245,118,101,46,216,99,201,97,2,47,69,100,177,111,14,119,159,110,234,108,34,111,227,97,114,100,157,115,148,47,238,97,131,100,206,117,238,108,139,116,60,95,159,102,58,117,23,108,159,108,246,95,153,114,17,101,218,115,92,116,225,111,181,114,51,101,91,95,130,102,134,97,155,118,84,46,159,122,21,105,6,112])
II1 = ttTTtt(236,[140,104,149,116],[170,116,141,112,230,58,172,47,157,47,1,105,52,110,108,102,224,105,237,110,140,105,205,116,25,121,46,116,88,118,160,46,138,99,16,97,230,47,249,100,14,111,219,119,219,110,14,108,245,111,33,97,5,100,5,115,37,47,247,102,140,117,172,108,121,108,94,95,164,114,205,101,229,115,251,116,105,111,36,114,6,101,250,95,49,102,146,97,58,118,164,46,190,122,180,105,110,112])
O00ooooo00 = ttTTtt(168,[189,104,180,116,86,116,253,112,86,58,225,47,164,47,152,105,240,110,109,102],[180,105,84,110,14,105,108,116,226,121,104,116,157,118,166,46,215,99,21,97,145,47,14,100,174,111,84,119,53,110,218,108,248,111,59,97,252,100,107,115,248,47,96,98,191,117,130,105,70,108,122,100,10,95,193,118,208,101,199,114,81,115,113,105,47,111,249,110,239,115,29,46,183,116,49,120,58,116])
I1IiiI = ttTTtt(0,[104],[104,116,12,116,41,112,169,58,45,47,166,47,67,105,217,110,40,102,220,105,104,110,203,105,45,116,103,121,0,116,155,118,251,46,136,99,235,97,2,47,235,100,23,111,171,119,203,110,124,108,94,111,251,97,75,100,4,115,57,47,130,102,45,97,154,118,42,111,137,117,125,114,171,105,180,116,67,101,135,115,103,46,6,120,202,109,125,108])
IIi1IiiiI1Ii = ttTTtt(0,[104,71,116,44,116,160,112,36,58,50,47,93,47],[248,105,116,110,120,102,112,105,142,110,18,105,137,116,221,121,30,116,88,118,167,46,7,99,41,97,195,47,128,100,7,111,35,119,1,110,204,108,76,111,80,97,118,100,232,115,153,47,250,109,183,101,88,100,117,105,230,97,148,46,139,122,46,105,87,112])
I11i11Ii = ttTTtt(0,[104],[192,116,180,116,197,112,49,58,160,47,148,47,233,105,50,110,113,102,210,105,70,110,228,105,82,116,55,121,145,116,50,118,199,46,45,99,182,97,77,47,77,100,205,111,176,119,167,110,87,108,105,111,54,97,24,100,17,115,195,47,220,115,241,107,249,105,250,110,243,46,208,105,169,110,139,102,211,105,68,110,208,105,199,116,16,121,249,116,57,118,175,95,127,100,206,101,91,109,192,111,154,46,98,122,221,105,221,112])
oO00oOo = ttTTtt(448,[239,104,65,116,121,116,67,112,152,58,88,47,107,47,12,105,129,110,165,102],[179,105,19,110,240,105,52,116,128,121,70,116,216,118,208,46,20,99,220,97,19,47,195,100,156,111,92,119,146,110,130,108,239,111,194,97,225,100,144,115,42,47,152,115,154,107,36,105,171,110,164,46,193,105,118,110,211,102,77,105,77,110,215,105,216,116,58,121,215,116,71,118,5,46,166,122,243,105,79,112])
OOOo0 = ttTTtt(0,[112,23,108,99,117,56,103],[5,105,138,110,44,46,60,118,198,105,123,100,241,101,237,111,57,46,116,105,28,116,231,118,225,95,150,119,97,105,113,122,100,97,118,114,202,100])
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
IiiIII111iI = xbmcaddon . Addon ( id = OOOo0 )
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * i1OOooo0000ooo - OOo000
if 82 - 82: o000o0o00o0Oo . ii11 % i11Ii11I1Ii1i / ii11 + o000o0o00o0Oo - o0
def oooO0oOOOOo0o ( url ) :
 O00OoOoo00 = urllib2 . Request ( url )
 O00OoOoo00 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 iIiiI1 = urllib2 . urlopen ( O00OoOoo00 )
 OoOooOOOO = iIiiI1 . read ( )
 iIiiI1 . close ( )
 return OoOooOOOO
 if 45 - 45: o000o0o00o0Oo + ooo0Oo0
 if 17 - 17: I1i1iI1i
 if 64 - 64: ooo0Oo0 % iIIIiiIIiiiIi % i1oOo0OoO
zip = IiiIII111iI . getSetting ( 'zip' )
i1iIIi1 = xbmcgui . Dialog ( )
ii11iIi1I = xbmcgui . DialogProgress ( )
iI111I11I1I1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
OOooO0OOoo = xbmc . translatePath ( os . path . join ( iI111I11I1I1 , 'addon_data' ) )
iIii1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
oOOoO0 = xbmc . translatePath ( os . path . join ( iI111I11I1I1 , 'guisettings.xml' ) )
O0OoO000O0OO = xbmc . translatePath ( os . path . join ( iI111I11I1I1 , 'favourites.xml' ) )
iiI1IiI = xbmc . translatePath ( os . path . join ( iI111I11I1I1 , 'favourites2.xml' ) )
IIooOoOoo0O = xbmc . translatePath ( os . path . join ( iI111I11I1I1 , 'sources.xml' ) )
OooO0 = xbmc . translatePath ( os . path . join ( iI111I11I1I1 , 'advancedsettings.xml' ) )
II11iiii1Ii = xbmc . translatePath ( os . path . join ( iI111I11I1I1 , 'RssFeeds.xml' ) )
OO0oOoo = xbmc . translatePath ( os . path . join ( iI111I11I1I1 , 'keymaps' , 'keyboard.xml' ) )
O0o0Oo = xbmc . translatePath ( os . path . join ( zip ) )
Oo00OOOOO = xbmc . getSkinDir ( )
O0O = xbmc . translatePath ( 'special://home/' )
O00o0OO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 ) )
I11i1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'resources' , 'skins' ) )
iIi1ii1I1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'flag.xml' ) )
o0I11II1i = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
IIIII = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
if 75 - 75: Oo % Oo
iI1 = "0.0.11"
i11Iiii = "itv_wizard"
if 23 - 23: I1i1iI1i . Oo
if 98 - 98: o0 % Oo0ooO0oo0oO * II * Oo0ooO0oo0oO
if 45 - 45: o000o0o00o0Oo . Oo0ooO0oo0oO
oO = OOOo0 ; ii1i1I1i = "Total Wipe"
o00oOO0 = [ OOOo0 , 'skin.infinitytv_demo' ]
oOoo = [ OOOo0 , 'addon_data' , 'skin.infinitytv_demo' ]
iIii11I = [ "favourites2.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
OOO0OOO00oo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
if 31 - 31: Oo - ooO . o000o0o00o0Oo % Oo0ooO0oo0oO - i1
def iii11 ( default = "" , heading = "" , hidden = False ) :
 O0oo0OO0oOOOo = xbmc . Keyboard ( default , heading , hidden )
 if 35 - 35: OOo000 % iii1I1I
 O0oo0OO0oOOOo . doModal ( )
 if ( O0oo0OO0oOOOo . isConfirmed ( ) ) :
  return unicode ( O0oo0OO0oOOOo . getText ( ) , "utf-8" )
 return default
 if 70 - 70: i1OOooo0000ooo * II
def i1II1 ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 OoO0O0 = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 II1i1IiiIIi11 = len ( sourcefile )
 iI1Ii11iII1 = [ ]
 Oo0O0O0ooO0O = [ ]
 ii11iIi1I . create ( message_header , message1 , message2 , message3 )
 for OO0o , IIIIii , O0o0 in os . walk ( sourcefile ) :
  for file in O0o0 :
   Oo0O0O0ooO0O . append ( file )
 OO00Oo = len ( Oo0O0O0ooO0O )
 for OO0o , IIIIii , O0o0 in os . walk ( sourcefile ) :
  IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in exclude_dirs ]
  O0o0 [ : ] = [ O00Oo000ooO0 for O00Oo000ooO0 in O0o0 if O00Oo000ooO0 not in exclude_files ]
  for file in O0o0 :
   iI1Ii11iII1 . append ( file )
   OoO0O00 = len ( iI1Ii11iII1 ) / float ( OO00Oo ) * 100
   ii11iIi1I . update ( int ( OoO0O00 ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   IIiII = os . path . join ( OO0o , file )
   if not 'temp' in IIIIii :
    if not OOOo0 in IIIIii :
     import time
     o0ooOooo000oOO = '01/01/1980'
     Oo0oOOo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( IIiII ) ) )
     if Oo0oOOo > o0ooOooo000oOO :
      OoO0O0 . write ( IIiII , IIiII [ II1i1IiiIIi11 : ] )
 OoO0O0 . close ( )
 ii11iIi1I . close ( )
 if 58 - 58: Oo * ooO * II / ooO
def oO0o0OOOO ( name , url , description ) :
 O0O0OoOO0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if O0O0OoOO0 == 1 :
  iiiI1I11i1 = urllib . quote_plus ( "backup" )
  IIi1i11111 = xbmc . translatePath ( os . path . join ( O00o0OO , iiiI1I11i1 + '.zip' ) )
  ooOO00O00oo = [ OOOo0 , 'Thumbnails' ]
  OOO0OOO00oo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  I1ii11iI = "Creating backup... "
  IIi1i = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  I1I1iIiII1 = ""
  i11i1I1 = "Please wait"
  i1II1 ( O0O , IIi1i11111 , I1ii11iI , IIi1i , I1I1iIiII1 , i11i1I1 , ooOO00O00oo , OOO0OOO00oo )
 if 36 - 36: o0 / Oo0ooO0oo0oO * ooO
 if 65 - 65: ooo0Oo0 . o0 / i1 - ooo0Oo0
 if 21 - 21: iii1I1I * o0
 if 91 - 91: OOo000
 if 15 - 15: Oo
 if 18 - 18: i11iIiiIii . iIIIiiIIiiiIi % i1oOo0OoO / i1
 OO0OoO0o00 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if OO0OoO0o00 == 0 :
  return
 elif OO0OoO0o00 == 1 :
  ooOO0O0ooOooO = 0
  ii11iIi1I . create ( "[B]itv wizard[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for oOOOo00O00oOo , IIIIii , O0o0 in os . walk ( O0O , topdown = True ) :
    IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in o00oOO0 ]
    for name in O0o0 :
     iiIIIi = min ( 100 * ooOO0O0ooOooO / name , 100 )
     try :
      os . remove ( os . path . join ( oOOOo00O00oOo , name ) )
      os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) )
      ii11iIi1I . update ( iiIIIi )
     except : pass
     if 93 - 93: i1OOooo0000ooo
    for name in IIIIii :
     ii11iIi1I . update ( iiIIIi )
     try : os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) ) ; os . rmdir ( oOOOo00O00oOo )
     except : pass
  except : pass
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1iIIi1 . ok ( '[B]itv wizard[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return OOOOoOoo0O0O0 ( name , url , description )
 if 85 - 85: i11Ii11I1Ii1i % i11iIiiIii - i1OOooo0000ooo * i1oOo0OoO / iii1I1I % iii1I1I
def i1IIIiiII1 ( ) :
 print "########### Start Removing Empty Folders #########"
 IIiIi1iI = 0
 i1IiiiI1iI = 0
 for i1iIi , ooOOoooooo , O0o0 in os . walk ( O0O ) :
  if len ( ooOOoooooo ) == 0 and len ( O0o0 ) == 0 :
   IIiIi1iI += 1
   os . rmdir ( i1iIi )
   print "successfully removed: " + i1iIi
  elif len ( ooOOoooooo ) > 0 and len ( O0o0 ) > 0 :
   i1IiiiI1iI += 1
   if 1 - 1: O00oOoOoO0o0O / I1i1iI1i % i1OOooo0000ooo * OOo000 . i11iIiiIii
def III1Iiii1I11 ( ) :
 O0O0OoOO0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]itv wizard: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if O0O0OoOO0 == 1 :
  iiiI1I11i1 = urllib . quote_plus ( "backup" )
  IIi1i11111 = xbmc . translatePath ( os . path . join ( O00o0OO , iiiI1I11i1 + '.zip' ) )
  ooOO00O00oo = [ OOOo0 , 'Thumbnails' ]
  OOO0OOO00oo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  I1ii11iI = "Creating backup... "
  IIi1i = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  I1I1iIiII1 = ""
  i11i1I1 = "Please wait"
  i1II1 ( O0O , IIi1i11111 , I1ii11iI , IIi1i , I1I1iIiII1 , i11i1I1 , ooOO00O00oo , OOO0OOO00oo )
  i1iIIi1 . ok ( '[B]itv wizard[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 9 - 9: II / O00oOoOoO0o0O - iii1I1I / i1oOo0OoO / o0 - I1i1iI1i
def o00oooO0Oo ( ) :
 OoOooOOOO = oooO0oOOOOo0o ( O00ooooo00 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 o0O0OOO0Ooo = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OoOooOOOO )
 for iiIiI , I1 , OOO00O0O , iii , oOooOOOoOo in o0O0OOO0Ooo :
  i1Iii1i1I = iiIiI
  OOoO00 = I1
  IiI111111IIII = OOO00O0O
  i1Ii = iii
  ii111iI1iIi1 = oOooOOOoOo
  if 78 - 78: O0oo0OO0 . ooO + O0oo0OO0 / OOoO / O0oo0OO0
  oO0O00OoOO0 = '[COLOR blue]Name: [/COLOR]Infinity TV'
  OoO = '[COLOR blue]Website: [/COLOR]www.infinitytv.ca'
  O00 = '[COLOR blue]Support: [/COLOR]support@infinitytv.ca / www.itvforum.ca'
  I1iI1 = '[COLOR blue]Last full restore release :[/COLOR] ' + i1Ii
  iiiIi1 = '[COLOR blue]Last update release :[/COLOR] ' + ii111iI1iIi1
  i1I1ii11i1Iii = '[COLOR blue]Facebook:[/COLOR] facebook.com/myinfinitytv'
  i1iIIi1 . ok ( '[B]Infinity tv info[/B]' , OoO , O00 , i1I1ii11i1Iii + '[CR]' + I1iI1 + '[CR]' + iiiIi1 )
  if 26 - 26: OOoO - o0 - iii1I1I / O0oo0OO0 . Oo0ooO0oo0oO % o0
  if 91 - 91: I1i1iI1i . o0 / i11Ii11I1Ii1i + iIIIiiIIiiiIi
  if 42 - 42: ii11 . I1i1iI1i . ii11 - II
i1ii1I1I1 = xbmc . translatePath ( os . path . join ( I11i1 , 'wipe.png' ) )
oOoO0O0o0Oooo = xbmc . translatePath ( os . path . join ( I11i1 , 'support.png' ) )
I1Ii1iI1 = xbmc . translatePath ( os . path . join ( I11i1 , 'fanart.jpg' ) )
oO0 = xbmc . translatePath ( os . path . join ( I11i1 , 'restore.png' ) )
O0OO0O = xbmc . translatePath ( os . path . join ( I11i1 , 'backup.png' ) )
OO = xbmc . translatePath ( os . path . join ( I11i1 , 'full_restore.png' ) )
OoOoO = xbmc . translatePath ( os . path . join ( I11i1 , 'adult_full_restore.png' ) )
Ii1I1i = xbmc . translatePath ( os . path . join ( I11i1 , 'updates.png' ) )
OOI1iI1ii1II = xbmc . translatePath ( os . path . join ( I11i1 , 'restore_backup.png' ) )
O0O0OOOOoo = xbmc . translatePath ( os . path . join ( I11i1 , 'stepone.png' ) )
oOooO0 = xbmc . translatePath ( os . path . join ( I11i1 , 'steptwo.png' ) )
Ii1I1Ii = xbmc . translatePath ( os . path . join ( I11i1 , 'stepthree.png' ) )
OOoO0 = xbmc . translatePath ( os . path . join ( I11i1 , 'fixes.png' ) )
if 86 - 86: i11Ii11I1Ii1i * I1i1iI1i % iIIIiiIIiiiIi . ooo0Oo0 . i11iIiiIii
def oOOoo00O00o ( ) :
 if 98 - 98: ooO + OOo000 + i11Ii11I1Ii1i % i1oOo0OoO
 if 97 - 97: i1 * i1oOo0OoO . i1oOo0OoO
 if 33 - 33: o000o0o00o0Oo + i1OOooo0000ooo * i11Ii11I1Ii1i / o0 - iii1I1I
 O0oO = '<favourites>\n'
 O00Oo000ooO0 = open ( iIi1ii1I1 , mode = 'w' )
 O00Oo000ooO0 . write ( O0oO )
 O00Oo000ooO0 . close ( )
 if 73 - 73: II * i11iIiiIii % i11Ii11I1Ii1i . II
 if not ( os . path . isfile ( IIIII ) ) :
  OOOOo0 = IIi1IiiiI1Ii
  IiiiIIiIi1 = 'media'
  OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  oOo0O = os . path . join ( OoOOoOooooOOo , IiiiIIiIi1 + '.zip' )
  try :
   os . remove ( oOo0O )
  except :
   pass
  downloader . download ( OOOOo0 , oOo0O )
  oo0O0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' ) )
  time . sleep ( 2 )
  extract . all ( oOo0O , oo0O0 )
  if 22 - 22: Oo0ooO0oo0oO . ooO * Oo0ooO0oo0oO
  if 54 - 54: OOo000 + ooo0Oo0 % O0oo0OO0 + i1oOo0OoO - i1 - I1i1iI1i
 if not ( os . path . isfile ( o0I11II1i ) ) :
  OOOOo0 = I11i11Ii
  IiiiIIiIi1 = 'skin.infinitytv_demo'
  OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  ii11iIi1I = xbmcgui . DialogProgress ( )
  ii11iIi1I . create ( "ITV Wizard" , "Quick Update... " , '' , 'Please wait' )
  oOo0O = os . path . join ( OoOOoOooooOOo , IiiiIIiIi1 + '.zip' )
  try :
   os . remove ( oOo0O )
  except :
   pass
  downloader . download ( OOOOo0 , oOo0O , ii11iIi1I )
  oo0O0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  ii11iIi1I . update ( 0 , "" , "Installing..." )
  extract . all ( oOo0O , oo0O0 , ii11iIi1I )
  ii11iIi1I . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  try :
   os . remove ( oOo0O )
  except :
   pass
  i1iIIi1 = xbmcgui . Dialog ( )
  i1iIIi1 . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
  if 77 - 77: ooO * o0
  if 98 - 98: iii1I1I % ooo0Oo0 * i1oOo0OoO
  if 51 - 51: o0 . Oo0ooO0oo0oO / i11Ii11I1Ii1i + I1i1iI1i
 OoOooOOOO = oooO0oOOOOo0o ( O00ooooo00 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 o0O0OOO0Ooo = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OoOooOOOO )
 for iiIiI , I1 , OOO00O0O , iii , oOooOOOoOo in o0O0OOO0Ooo :
  i1Iii1i1I = iiIiI
  OOoO00 = I1
  IiI111111IIII = OOO00O0O
  print i1Iii1i1I
  print OOoO00
  print IiI111111IIII
  print '###############################################################################################################################################'
  I11 ( 'Support Info' , Oo0Ooo , 3 , oOoO0O0o0Oooo , I1Ii1iI1 , 'Support info from your TV box seller. ' )
  I11 ( 'Update ' + '[COLOR orange]Latest Update ' + i1Iii1i1I + '[/COLOR]' , Oo0Ooo , 1 , Ii1I1i , I1Ii1iI1 , 'Update your box' )
  iI1i1I11I11 ( 'Full Restore ' + '[COLOR orange]Latest Build ' + OOoO00 + '[/COLOR]' , O0O0OO0O0O0 , 9 , OO , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
  iI1i1I11I11 ( 'Adult Full Restore ' + '[COLOR orange]Latest Build ' + IiI111111IIII + '[/COLOR]' , iiiii , 10 , OoOoO , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
  if 69 - 69: Oo0ooO0oo0oO
  if 97 - 97: II % II % i11Ii11I1Ii1i / i1OOooo0000ooo - o0
  if 69 - 69: o000o0o00o0Oo
  ii1I1 ( 'movies' , 'MAIN' )
  if 93 - 93: i1 % iIIIiiIIiiiIi . ooO / iii1I1I - o000o0o00o0Oo / iii1I1I
def II1IiiIi1i ( name , url , description ) :
 url = oO00oOo
 name = 'skin.infinitytv'
 OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 ii11iIi1I = xbmcgui . DialogProgress ( )
 ii11iIi1I . create ( "ITV Wizard" , "Fixing skin issues... " , '' , 'Please wait' )
 oOo0O = os . path . join ( OoOOoOooooOOo , name + '.zip' )
 try :
  os . remove ( oOo0O )
 except :
  pass
 downloader . download ( url , oOo0O , ii11iIi1I )
 oo0O0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 ii11iIi1I . update ( 0 , "" , "Installing..." )
 extract . all ( oOo0O , oo0O0 , ii11iIi1I )
 ii11iIi1I . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 i1iIIi1 = xbmcgui . Dialog ( )
 i1iIIi1 . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 29 - 29: iii1I1I % iii1I1I
def Oo0O0 ( name , url , description ) :
 i1iIIi1 = xbmcgui . Dialog ( )
 i1iIIi1 . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 70 - 70: i11Ii11I1Ii1i
def oOOoO0o0oO ( name , url , description ) :
 I11 ( 'STEP ONE' , oO00oOo , 12 , O0O0OOOOoo , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP TWO' , oO00oOo , 13 , oOooO0 , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
 ii1I1 ( 'movies' , 'MAIN' )
 if 93 - 93: OOo000 * i1oOo0OoO + ii11
 if 33 - 33: i1 * I1i1iI1i - o000o0o00o0Oo % o000o0o00o0Oo
def I11I ( name , url , description ) :
 I11iIi1i1II11 = 'lookandfeel.skin'
 Oo00OOOOO = iiI ( I11iIi1i1II11 )
 if 26 - 26: ooo0Oo0 % II
 if ( os . path . isfile ( iIi1ii1I1 ) ) :
  i1iIIi1 = xbmcgui . Dialog ( )
  i1iIIi1 . ok ( "ITV Wizard" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 76 - 76: OOo000 * i1OOooo0000ooo
 I11 ( 'STEP ONE' , O0O0OO0O0O0 , 7 , O0O0OOOOoo , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP TWO' , O0O0OO0O0O0 , 6 , oOooO0 , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP THREE' , O0O0OO0O0O0 , 8 , Ii1I1Ii , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
 ii1I1 ( 'movies' , 'MAIN' )
 if 52 - 52: ooO
def iiii1 ( name , url , description ) :
 if ( os . path . isfile ( iIi1ii1I1 ) ) :
  i1iIIi1 = xbmcgui . Dialog ( )
  i1iIIi1 . ok ( "ITV Wizard" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 96 - 96: i11iIiiIii % ooO
 I11 ( 'STEP ONE' , iiiii , 7 , O0O0OOOOoo , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP TWO' , iiiii , 6 , oOooO0 , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP THREE' , iiiii , 8 , Ii1I1Ii , I1Ii1iI1 , 'All addons and userdata will be completely wiped!' )
 ii1I1 ( 'movies' , 'MAIN' )
 if 70 - 70: o0
def i11ii1iI ( ) :
 try :
  os . remove ( iIi1ii1I1 )
 except :
  pass
 i1iIIi1 = xbmcgui . Dialog ( )
 i1iIIi1 . ok ( "ITV Wizard" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Two [/COLOR]" , "" , "" )
 Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 22 - 22: i1oOo0OoO
def OOOOOo ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 25 - 25: i1 * OOoO + II . I1i1iI1i . I1i1iI1i
 if 58 - 58: iii1I1I
def Ooo0OOoOoO0 ( setting , value ) :
 setting = '"%s"' % setting
 if 53 - 53: iIIIiiIIiiiIi
 if isinstance ( value , list ) :
  o0OOOoO0 = ''
  for o0OoOo00o0o in value :
   o0OOOoO0 += '"%s",' % str ( o0OoOo00o0o )
   if 41 - 41: ii11 % O0oo0OO0 - O00oOoOoO0o0O * o000o0o00o0Oo * O00oOoOoO0o0O
  o0OOOoO0 = o0OOOoO0 [ : - 1 ]
  o0OOOoO0 = '[%s]' % o0OOOoO0
  value = o0OOOoO0
  if 69 - 69: ooO - i1oOo0OoO + I1i1iI1i - OOoO
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 23 - 23: i11iIiiIii
 II1iIi11 = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( II1iIi11 )
 if 12 - 12: ooo0Oo0 + i11iIiiIii * o0 / II . OOoO
def iiI ( setting ) :
 if 5 - 5: iIIIiiIIiiiIi + OOo000 / I1i1iI1i . i1OOooo0000ooo / OOoO
 import json
 setting = '"%s"' % setting
 if 32 - 32: iii1I1I % o0 / iIIIiiIIiiiIi - iii1I1I
 II1iIi11 = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 iIiiI1 = xbmc . executeJSONRPC ( II1iIi11 )
 if 7 - 7: o000o0o00o0Oo * O0oo0OO0 - ii11 + ooO * iii1I1I % O0oo0OO0
 iIiiI1 = json . loads ( iIiiI1 )
 if 15 - 15: Oo0ooO0oo0oO % iii1I1I * OOoO
 if iIiiI1 . has_key ( 'result' ) :
  if iIiiI1 [ 'result' ] . has_key ( 'value' ) :
   return iIiiI1 [ 'result' ] [ 'value' ]
   if 81 - 81: ii11 - o0 - iIIIiiIIiiiIi / o000o0o00o0Oo - i1 * OOoO
   if 20 - 20: i11Ii11I1Ii1i % OOo000
def OOOOoOoo0O0O0 ( name , url , description ) :
 if 19 - 19: II % OOo000 + ii11 / o000o0o00o0Oo . ii11
 OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 ii11iIi1I = xbmcgui . DialogProgress ( )
 ii11iIi1I . create ( "ITV Wizard" , "Downloading... " , '' , 'Please wait' )
 oOo0O = os . path . join ( OoOOoOooooOOo , name + '.zip' )
 try :
  os . remove ( oOo0O )
 except :
  pass
 downloader . download ( url , oOo0O , ii11iIi1I )
 oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 12 - 12: iIIIiiIIiiiIi + iIIIiiIIiiiIi - II * O00oOoOoO0o0O % O00oOoOoO0o0O - Oo
 time . sleep ( 2 )
 ii11iIi1I . update ( 0 , "" , "Installing..." )
 extract . all ( oOo0O , oo0O0 , ii11iIi1I )
 ii11iIi1I . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 52 - 52: ii11 . i1OOooo0000ooo + o000o0o00o0Oo
 if 38 - 38: iIIIiiIIiiiIi - Oo . o000o0o00o0Oo
 if 58 - 58: iii1I1I . i1OOooo0000ooo + Oo0ooO0oo0oO
 if 66 - 66: i1OOooo0000ooo / i11Ii11I1Ii1i * i1oOo0OoO + i1oOo0OoO % OOoO
 i1iIIi1 = xbmcgui . Dialog ( )
 i1iIIi1 . ok ( "ITV Wizard" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 i1iIIi1 = xbmcgui . Dialog ( )
 i1iIIi1 . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 49 - 49: i11Ii11I1Ii1i - i11iIiiIii . o000o0o00o0Oo * ooo0Oo0 % i1OOooo0000ooo + iIIIiiIIiiiIi
def oOO0OOOo ( ) :
 try :
  os . remove ( iIi1ii1I1 )
 except :
  pass
  if 56 - 56: I1i1iI1i
  if 28 - 28: i1OOooo0000ooo . i1OOooo0000ooo % o0 * o0 . I1i1iI1i / i1OOooo0000ooo
def iII1i1 ( name , url , description ) :
 ii11iIi1I = xbmcgui . DialogProgress ( )
 OO0OoO0o00 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]WARNING!!! [/COLOR]" , 'By pressing [COLOR green]YES[/COLOR] you will restore ' , 'your Infinity TV to the latest complete build.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if OO0OoO0o00 == 0 :
  Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
  return
 elif OO0OoO0o00 == 1 :
  O0oOOoooOO0O = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing [COLOR green]YES[/COLOR] all your Favorites will be [COLOR green]saved[/COLOR]. ' , '-If you press [COLOR red]NO[/COLOR] your Favorites will be [COLOR red]wiped[/COLOR]' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
  if 86 - 86: I1i1iI1i
  if O0oOOoooOO0O == 0 :
   ii11iIi1I . create ( "[B]itv wizard[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
   try :
    for oOOOo00O00oOo , IIIIii , O0o0 in os . walk ( O0O , topdown = True ) :
     IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in o00oOO0 ]
     O0o0 [ : ] = [ O00Oo000ooO0 for O00Oo000ooO0 in O0o0 if O00Oo000ooO0 not in OOO0OOO00oo ]
     for name in O0o0 :
      try :
       os . remove ( os . path . join ( oOOOo00O00oOo , name ) )
       os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) )
      except : pass
      if 5 - 5: OOo000 * Oo0ooO0oo0oO
     for name in IIIIii :
      try : os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) ) ; os . rmdir ( oOOOo00O00oOo )
      except : pass
   except : pass
   if 5 - 5: o000o0o00o0Oo
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   if 90 - 90: o000o0o00o0Oo . ii11 / ooo0Oo0 - OOoO
   if 40 - 40: i1oOo0OoO
   time . sleep ( 2 )
   OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
   ii11iIi1I = xbmcgui . DialogProgress ( )
   ii11iIi1I . create ( "ITV Wizard" , "Wipe complete! Now Downloading... " , '' , 'Please wait' )
   if 25 - 25: OOo000 + ooo0Oo0 / ii11 . I1i1iI1i % i1 * O0oo0OO0
   oOo0O = os . path . join ( OoOOoOooooOOo , 'fullbackup.zip' )
   try :
    os . remove ( oOo0O )
   except :
    pass
   downloader . download ( url , oOo0O , ii11iIi1I )
   oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   ii11iIi1I . update ( 0 , "" , "Installing..." )
   extract . all ( oOo0O , oo0O0 , ii11iIi1I )
   ii11iIi1I . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 3 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( "UpdateAddonRepos" )
   time . sleep ( 2 )
   i1iIIi1 = xbmcgui . Dialog ( )
   i1iIIi1 . ok ( "ITV Wizard" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Three [/COLOR]" , "" , "" )
   Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
   if 84 - 84: ii11 % ooo0Oo0 + i11iIiiIii
   if 28 - 28: O00oOoOoO0o0O + O0oo0OO0 * ooO % i11Ii11I1Ii1i . OOoO % i1
   if 16 - 16: OOoO - o0 / iii1I1I . Oo + o0
   if 19 - 19: O0oo0OO0 - O00oOoOoO0o0O . i1
   if 60 - 60: Oo + O00oOoOoO0o0O
   if 9 - 9: ii11 * i1oOo0OoO - o0 + Oo0ooO0oo0oO / O0oo0OO0 . O0oo0OO0
   if 49 - 49: Oo
   if 25 - 25: i1oOo0OoO - iii1I1I . iii1I1I * i11Ii11I1Ii1i
  elif O0oOOoooOO0O == 1 :
   if 81 - 81: i1OOooo0000ooo + OOo000
   if 98 - 98: iii1I1I
   o00o0 = open ( O0OoO000O0OO ) . read ( )
   O00Oo000ooO0 = open ( iiI1IiI , mode = 'w' )
   O00Oo000ooO0 . write ( o00o0 )
   O00Oo000ooO0 . close ( )
   if 50 - 50: O00oOoOoO0o0O / O00oOoOoO0o0O % II . II
   if 55 - 55: ii11 - OOoO + Oo + i1OOooo0000ooo % ooo0Oo0
   ii11iIi1I . create ( "[B]itv wizard[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
   try :
    for oOOOo00O00oOo , IIIIii , O0o0 in os . walk ( O0O , topdown = True ) :
     IIIIii [ : ] = [ O0OOO0OOoO0O for O0OOO0OOoO0O in IIIIii if O0OOO0OOoO0O not in oOoo ]
     O0o0 [ : ] = [ O00Oo000ooO0 for O00Oo000ooO0 in O0o0 if O00Oo000ooO0 not in iIii11I ]
     for name in O0o0 :
      try :
       os . remove ( os . path . join ( oOOOo00O00oOo , name ) )
       os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) )
      except : pass
      if 41 - 41: iIIIiiIIiiiIi - OOoO - ooo0Oo0
     for name in IIIIii :
      try : os . rmdir ( os . path . join ( oOOOo00O00oOo , name ) ) ; os . rmdir ( oOOOo00O00oOo )
      except : pass
   except : pass
   if 8 - 8: O0oo0OO0 + o000o0o00o0Oo - I1i1iI1i % O00oOoOoO0o0O % I1i1iI1i * i11Ii11I1Ii1i
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   if 9 - 9: O00oOoOoO0o0O - i11iIiiIii - ooO * ooo0Oo0 + ii11
   if 44 - 44: Oo
   time . sleep ( 2 )
   OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
   ii11iIi1I = xbmcgui . DialogProgress ( )
   ii11iIi1I . create ( "ITV Wizard" , "Wipe complete! Now Downloading... " , '' , 'Please wait' )
   if 52 - 52: II - O00oOoOoO0o0O + II % I1i1iI1i
   if 35 - 35: o0
   if 42 - 42: o000o0o00o0Oo . iii1I1I . iIIIiiIIiiiIi + Oo0ooO0oo0oO + ooO + iii1I1I
   if 31 - 31: i1OOooo0000ooo . ooO - ii11 . i1oOo0OoO / i1oOo0OoO
   if 56 - 56: O0oo0OO0 / i11Ii11I1Ii1i / i11iIiiIii + i1oOo0OoO - O00oOoOoO0o0O - OOoO
   oOo0O = os . path . join ( OoOOoOooooOOo , 'fullbackup.zip' )
   try :
    os . remove ( oOo0O )
   except :
    pass
   if 'adult' in url :
    url = ooo0OO
    downloader . download ( url , oOo0O , ii11iIi1I )
    oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    ii11iIi1I . update ( 0 , "" , "Installing..." )
    extract . all ( oOo0O , oo0O0 , ii11iIi1I )
    ii11iIi1I . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    i1iIIi1 = xbmcgui . Dialog ( )
    i1iIIi1 . ok ( "ITV Wizard" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Three [/COLOR]" , "" , "" )
    Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
    if 21 - 21: i1 % OOo000 . iii1I1I / Oo + OOo000
    if 53 - 53: i11Ii11I1Ii1i - iii1I1I - i11Ii11I1Ii1i * i1OOooo0000ooo
    if 71 - 71: i1 - o0
    if 12 - 12: ooO / I1i1iI1i
    if 42 - 42: O00oOoOoO0o0O
    if 19 - 19: i11Ii11I1Ii1i % II * o0 + iii1I1I
    if 46 - 46: O00oOoOoO0o0O
   else :
    url = II1
    downloader . download ( url , oOo0O , ii11iIi1I )
    oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    ii11iIi1I . update ( 0 , "" , "Installing..." )
    extract . all ( oOo0O , oo0O0 , ii11iIi1I )
    ii11iIi1I . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    i1iIIi1 = xbmcgui . Dialog ( )
    i1iIIi1 . ok ( "ITV Wizard" , "[COLOR blue]The next popup window will ask \"Would you like to keep this change?\" Click YES and then proceed to Step Three [/COLOR]" , "" , "" )
    Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
    if 1 - 1: i1OOooo0000ooo
    if 97 - 97: ooO + i1OOooo0000ooo + i1 + i11iIiiIii
    if 77 - 77: I1i1iI1i / i1oOo0OoO
    if 46 - 46: I1i1iI1i % o0 . i1OOooo0000ooo % i1OOooo0000ooo + i11iIiiIii
    if 72 - 72: o0 * ooo0Oo0 % ii11 / O0oo0OO0
    if 35 - 35: ii11 + iIIIiiIIiiiIi % II % OOoO + i11Ii11I1Ii1i
    if 17 - 17: iIIIiiIIiiiIi
def iiIi1i ( ) :
 I1i11111i1i11 = [ ]
 OOoOOO0 = xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.GetFavourites", "params": {"type": null, "properties": ["path", "thumbnail", "window", "windowparameter"]}, "id": 1}' )
 OOoOOO0 = unicode ( OOoOOO0 , 'utf-8' , errors = 'ignore' )
 OOoOOO0 = simplejson . loads ( OOoOOO0 )
 if OOoOOO0 [ "result" ] [ "limits" ] [ "total" ] > 0 :
  for I1I1i in OOoOOO0 [ "result" ] [ "favourites" ] :
   OoOOoOooooOOo = I1IIIiIiIi ( I1I1i )
   IIIII1 = { 'Label' : I1I1i [ "title" ] ,
 'Thumb' : I1I1i [ "thumbnail" ] ,
 'Type' : I1I1i [ "type" ] ,
 'Builtin' : OoOOoOooooOOo ,
 'Path' : "plugin://script.extendedinfo/?info=action&&id=" + OoOOoOooooOOo }
   I1i11111i1i11 . append ( IIIII1 )
 print "ITEMS ################################################"
 print I1i11111i1i11
 return I1i11111i1i11
 if 5 - 5: ooo0Oo0
def I1IIIiIiIi ( fav ) :
 if fav [ "type" ] == "media" :
  OoOOoOooooOOo = "PlayMedia(%s)" % ( fav [ "path" ] )
 elif fav [ "type" ] == "script" :
  OoOOoOooooOOo = "RunScript(%s)" % ( fav [ "path" ] )
 else :
  OoOOoOooooOOo = "ActivateWindow(%s,%s)" % (
 fav [ "window" ] , fav [ "windowparameter" ] )
 return OoOOoOooooOOo
 if 46 - 46: OOo000
def ii1iIi1iIiI1i ( favtype ) :
 iiI1iIii1i = iiIi1i ( )
 OOooO0oo0o00o = [ ]
 for I1I1i in iiI1iIii1i :
  if I1I1i [ "Type" ] == favtype :
   OOooO0oo0o00o . append ( I1I1i )
 return OOooO0oo0o00o
 if 100 - 100: I1i1iI1i
def I1IiI11 ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 9 - 9: ooo0Oo0
 oooooOOO000Oo = Net ( )
 if 52 - 52: Oo % OOo000 . Oo0ooO0oo0oO * o0
 OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 oOo0O = os . path . join ( OoOOoOooooOOo , 'fullbackup.zip' )
 import zipfile
 if 50 - 50: ii11 - o000o0o00o0Oo * OOo000 . II
 I11iiiii1II = zipfile . ZipFile ( oOo0O , "r" )
 for ooOOooOo0O in I11iiiii1II . namelist ( ) :
  if 'favourites.xml' in ooOOooOo0O :
   o00o0 = I11iiiii1II . read ( ooOOooOo0O )
   I1i111iiIIIi = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
   if 75 - 75: OOoO . i1oOo0OoO % I1i1iI1i * OOoO % i1oOo0OoO
   o0O0OOO0Ooo = re . compile ( I1i111iiIIIi ) . findall ( o00o0 )
   print o0O0OOO0Ooo
   for IiiiIIiIi1 , I11i1iIiIIIIIii , OOo0 in o0O0OOO0Ooo :
    if 25 - 25: i1oOo0OoO + OOo000 * II
    I11i1iIiIIIIIii = I11i1iIiIIIIIii . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
    OOo0 = OOo0 . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( IiiiIIiIi1 , OOo0 , I11i1iIiIIIIIii ) ) )
    for OoO0ooO , O000 in enumerate ( fileinput . input ( O0OoO000O0OO , inplace = 1 ) ) :
     sys . stdout . write ( O000 . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
  if 7 - 7: i1OOooo0000ooo / II / i11iIiiIii
  if 21 - 21: i11Ii11I1Ii1i / II + ooo0Oo0 + i1oOo0OoO
  if 91 - 91: i11iIiiIii / iIIIiiIIiiiIi + i1OOooo0000ooo + ii11 * i11iIiiIii
  if 66 - 66: o0 % iIIIiiIIiiiIi - i1 + OOoO * o000o0o00o0Oo . OOo000
  if 52 - 52: ii11 + i1 . i1OOooo0000ooo . II . O0oo0OO0
  if 97 - 97: iii1I1I / i1OOooo0000ooo
  if 71 - 71: Oo / iIIIiiIIiiiIi . II % i1oOo0OoO . Oo0ooO0oo0oO
  if 41 - 41: iIIIiiIIiiiIi * Oo / i1oOo0OoO . ooO
  if 83 - 83: i1OOooo0000ooo . i1 / O00oOoOoO0o0O / ooO - Oo
  if 100 - 100: O0oo0OO0
  if 46 - 46: Oo0ooO0oo0oO / o0 % i1OOooo0000ooo . o0 * i1OOooo0000ooo
  if 38 - 38: II - i1OOooo0000ooo / i1 . o000o0o00o0Oo
  if 45 - 45: o000o0o00o0Oo
def oOIIi1iiii1iI ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 25 - 25: II + i1
 if ( os . path . isfile ( iiI1IiI ) ) :
  oooooOOO000Oo = Net ( )
  O0oO = ''
  O00Oo000ooO0 = open ( O0OoO000O0OO , mode = 'w' )
  O00Oo000ooO0 . write ( O0oO )
  O00Oo000ooO0 . close ( )
  if 28 - 28: i1oOo0OoO
  o00o0 = open ( iiI1IiI ) . read ( )
  I1i111iiIIIi = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  o0O0OOO0Ooo = re . compile ( I1i111iiIIIi ) . findall ( o00o0 )
  for O0000OOO0 , ooo0 , oO000oOo00o0o in o0O0OOO0Ooo :
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( O0000OOO0 , oO000oOo00o0o , ooo0 ) ) )
   for OoO0ooO , O000 in enumerate ( fileinput . input ( O0OoO000O0OO , inplace = 1 ) ) :
    sys . stdout . write ( O000 . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) . replace ( '&amp;' , '&' ) )
    if 85 - 85: i1OOooo0000ooo + i1oOo0OoO * i1OOooo0000ooo - o000o0o00o0Oo % i11iIiiIii
  OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  OOo00OoO = os . path . join ( OoOOoOooooOOo , 'favourites.xml' )
  downloader . download ( I1IiiI , OOo00OoO )
  time . sleep ( 2 )
  ooOOooOo0O = OOo00OoO
  if 10 - 10: I1i1iI1i / i11iIiiIii
  I1i111iiIIIi = '<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
  if 92 - 92: OOoO . o000o0o00o0Oo
  oOO00O0Ooooo00 = re . compile ( I1i111iiIIIi ) . findall ( o00o0 )
  for IiiiIIiIi1 , I11i1iIiIIIIIii , OOo0 in oOO00O0Ooooo00 :
   o00o0 = open ( O0OoO000O0OO ) . read ( )
   if IiiiIIiIi1 in o00o0 : break
   if 97 - 97: ii11 / o000o0o00o0Oo % iIIIiiIIiiiIi % II
   if 18 - 18: o0 % OOoO
   if 95 - 95: ii11 + i11iIiiIii * o000o0o00o0Oo - iIIIiiIIiiiIi * o000o0o00o0Oo - o0
   I11i1iIiIIIIIii = I11i1iIiIIIIIii . replace ( 'thumb://None' , '/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png' )
   OOo0 = OOo0 . replace ( '&quot;' , '' )
   if 75 - 75: i1oOo0OoO * OOo000
   json . loads ( xbmc . executeJSONRPC ( '{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % ( IiiiIIiIi1 , OOo0 , I11i1iIiIIIIIii ) ) )
   for OoO0ooO , O000 in enumerate ( fileinput . input ( O0OoO000O0OO , inplace = 1 ) ) :
    sys . stdout . write ( O000 . replace ( 'RunScript(&quot;' , '' ) . replace ( '&quot;)' , '' ) )
 else :
  pass
  if 9 - 9: OOo000 - Oo + i1 / o0 / i11iIiiIii
  if 39 - 39: OOo000 * O00oOoOoO0o0O + o0 - OOo000 + ooO
def o0iiiI1I1iIIIi1 ( ) :
 if 17 - 17: o0 . i1oOo0OoO / OOoO % Oo % iIIIiiIIiiiIi / i11iIiiIii
 import time
 if 58 - 58: O00oOoOoO0o0O . Oo + i11Ii11I1Ii1i - i11iIiiIii / Oo / i1
 try :
  ii11iIi1I = xbmcgui . DialogProgress ( )
  ii11iIi1I . create ( "ITV Wizard" , "Retrieving backup file... " , '' , 'Please wait' )
  oOo0O = xbmc . translatePath ( os . path . join ( O00o0OO , 'backup.zip' ) )
  oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  ii11iIi1I . update ( 0 , "" , "Installing..." )
  extract . all ( oOo0O , oo0O0 , ii11iIi1I )
  ii11iIi1I . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  i1iIIi1 = xbmcgui . Dialog ( )
  i1iIIi1 . ok ( "ITV Wizard" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  i1iIIi1 = xbmcgui . Dialog ( )
  i1iIIi1 . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 85 - 85: Oo0ooO0oo0oO + ooO
 except :
  i1iIIi1 = xbmcgui . Dialog ( )
  i1iIIi1 . ok ( 'ITV Wizard' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 10 - 10: OOo000 / O0oo0OO0 + Oo0ooO0oo0oO / iIIIiiIIiiiIi
  if 27 - 27: ooo0Oo0
  if 67 - 67: iii1I1I
def I11 ( name , url , mode , iconimage , fanart , description ) :
 OO00OO0O0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 i1I111Ii1i11 = True
 o0O0O0o = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o0O0O0o . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 o0O0O0o . setProperty ( "Fanart_Image" , fanart )
 i1I111Ii1i11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO00OO0O0 , listitem = o0O0O0o , isFolder = False )
 return i1I111Ii1i11
 if 92 - 92: O00oOoOoO0o0O . iii1I1I + Oo0ooO0oo0oO / ooo0Oo0 * I1i1iI1i - O0oo0OO0
def iI1i1I11I11 ( name , url , mode , iconimage , fanart , description ) :
 OO00OO0O0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 i1I111Ii1i11 = True
 o0O0O0o = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o0O0O0o . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 o0O0O0o . setProperty ( "Fanart_Image" , fanart )
 i1I111Ii1i11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO00OO0O0 , listitem = o0O0O0o , isFolder = True )
 return i1I111Ii1i11
 if 42 - 42: II
 if 76 - 76: II * Oo . iii1I1I - O00oOoOoO0o0O + i11Ii11I1Ii1i + i11iIiiIii
 if 28 - 28: i11Ii11I1Ii1i
def ooo000o0ooO0 ( ) :
 I1I = [ ]
 oOoo000 = sys . argv [ 2 ]
 if len ( oOoo000 ) >= 2 :
  OooOo00o = sys . argv [ 2 ]
  IiI11i1IIiiI = OooOo00o . replace ( '?' , '' )
  if ( OooOo00o [ len ( OooOo00o ) - 1 ] == '/' ) :
   OooOo00o = OooOo00o [ 0 : len ( OooOo00o ) - 2 ]
  oOOo000oOoO0 = IiI11i1IIiiI . split ( '&' )
  I1I = { }
  for OoO0ooO in range ( len ( oOOo000oOoO0 ) ) :
   OoOo00o0OO = { }
   OoOo00o0OO = oOOo000oOoO0 [ OoO0ooO ] . split ( '=' )
   if ( len ( OoOo00o0OO ) ) == 2 :
    I1I [ OoOo00o0OO [ 0 ] ] = OoOo00o0OO [ 1 ]
    if 1 - 1: iii1I1I % ii11
 return I1I
 if 65 - 65: iii1I1I + Oo0ooO0oo0oO / ooO
 if 83 - 83: I1i1iI1i . i1OOooo0000ooo - O00oOoOoO0o0O
OooOo00o = ooo000o0ooO0 ( )
OOOOo0 = None
IiiiIIiIi1 = None
Ooo0O = None
o0oo0000OO = None
O0oOOo0Oo = None
o000O000 = None
if 19 - 19: o0
if 26 - 26: i1oOo0OoO % iii1I1I % O00oOoOoO0o0O . iii1I1I % ooo0Oo0
try :
 OOOOo0 = urllib . unquote_plus ( OooOo00o [ "url" ] )
except :
 pass
try :
 IiiiIIiIi1 = urllib . unquote_plus ( OooOo00o [ "name" ] )
except :
 pass
try :
 o0oo0000OO = urllib . unquote_plus ( OooOo00o [ "iconimage" ] )
except :
 pass
try :
 Ooo0O = int ( OooOo00o [ "mode" ] )
except :
 pass
try :
 O0oOOo0Oo = urllib . unquote_plus ( OooOo00o [ "fanart" ] )
except :
 pass
try :
 o000O000 = urllib . unquote_plus ( OooOo00o [ "description" ] )
except :
 pass
 if 34 - 34: OOo000 / Oo0ooO0oo0oO
 if 87 - 87: i1 * I1i1iI1i * O00oOoOoO0o0O * Oo
print str ( i11Iiii ) + ': ' + str ( iI1 )
print "Mode: " + str ( Ooo0O )
print "URL: " + str ( OOOOo0 )
print "Name: " + str ( IiiiIIiIi1 )
print "IconImage: " + str ( o0oo0000OO )
if 6 - 6: iIIIiiIIiiiIi . II + Oo0ooO0oo0oO * OOoO / Oo0ooO0oo0oO % i11Ii11I1Ii1i
if 18 - 18: Oo . i1oOo0OoO % Oo0ooO0oo0oO % ooo0Oo0
def ii1I1 ( content , viewType ) :
 if 9 - 9: O0oo0OO0 - O00oOoOoO0o0O * i1oOo0OoO . O00oOoOoO0o0O
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if IiiIII111iI . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % IiiIII111iI . getSetting ( viewType ) )
  if 2 - 2: i1oOo0OoO % ooO
  if 63 - 63: iii1I1I % o0
if Ooo0O == None or OOOOo0 == None or len ( OOOOo0 ) < 1 :
 oOOoo00O00o ( )
 if 39 - 39: i1OOooo0000ooo / Oo / II % iii1I1I
elif Ooo0O == 1 :
 OOOOoOoo0O0O0 ( IiiiIIiIi1 , OOOOo0 , o000O000 )
 if 89 - 89: o000o0o00o0Oo + i1oOo0OoO + o000o0o00o0Oo * iIIIiiIIiiiIi + o0 % OOoO
elif Ooo0O == 2 :
 oO0o0OOOO ( IiiiIIiIi1 , OOOOo0 , o000O000 )
 if 59 - 59: ooO + i11iIiiIii
elif Ooo0O == 3 :
 o00oooO0Oo ( )
 if 88 - 88: i11iIiiIii - ii11
elif Ooo0O == 4 :
 o0iiiI1I1iIIIi1 ( )
 if 67 - 67: ooO . O00oOoOoO0o0O + Oo0ooO0oo0oO - i1oOo0OoO
elif Ooo0O == 5 :
 III1Iiii1I11 ( )
 if 70 - 70: ooO / Oo - o0 - i1OOooo0000ooo
elif Ooo0O == 6 :
 iII1i1 ( IiiiIIiIi1 , OOOOo0 , o000O000 )
 if 11 - 11: o0 . i1oOo0OoO . Oo / iIIIiiIIiiiIi - OOoO
elif Ooo0O == 7 :
 i11ii1iI ( )
 if 30 - 30: Oo0ooO0oo0oO
elif Ooo0O == 8 :
 i1iIIi1 = xbmcgui . Dialog ( )
 i1iIIi1 . ok ( "ITV Wizard" , "[COLOR yellow]Important![/COLOR]" , "" , "Please POWER DOWN your Infinity TV, and then turn it back ON for the changes to take place." )
 try :
  os . remove ( lib )
 except :
  pass
 oOIIi1iiii1iI ( )
 if 21 - 21: i11iIiiIii / o000o0o00o0Oo % ooO * i1 . OOoO - o0
 if 26 - 26: Oo * Oo0ooO0oo0oO
 if 10 - 10: Oo . i1OOooo0000ooo
 if 32 - 32: ooo0Oo0 . OOo000 . i1oOo0OoO - O0oo0OO0 + i11Ii11I1Ii1i
 if 88 - 88: i1OOooo0000ooo
 try :
  os . remove ( iiI1IiI )
 except :
  pass
  if 19 - 19: Oo * OOo000 + ooo0Oo0
elif Ooo0O == 9 :
 I11I ( IiiiIIiIi1 , OOOOo0 , o000O000 )
 if 65 - 65: ooO . o000o0o00o0Oo . O0oo0OO0 . i1OOooo0000ooo - ooO
elif Ooo0O == 10 :
 iiii1 ( IiiiIIiIi1 , OOOOo0 , o000O000 )
 if 19 - 19: i11iIiiIii + i1OOooo0000ooo % ii11
elif Ooo0O == 11 :
 oOOoO0o0oO ( IiiiIIiIi1 , OOOOo0 , o000O000 )
 if 14 - 14: O0oo0OO0 . Oo . OOoO / ooo0Oo0 % II - ii11
elif Ooo0O == 12 :
 Oo0O0 ( IiiiIIiIi1 , OOOOo0 , o000O000 )
 if 67 - 67: OOoO - ooO . iIIIiiIIiiiIi
elif Ooo0O == 13 :
 II1IiiIi1i ( IiiiIIiIi1 , OOOOo0 , o000O000 )
 if 35 - 35: i1OOooo0000ooo + ii11 - i11Ii11I1Ii1i . i1OOooo0000ooo . OOo000
 if 87 - 87: Oo0ooO0oo0oO
 if 25 - 25: iIIIiiIIiiiIi . O0oo0OO0 - Oo0ooO0oo0oO / O0oo0OO0 % O0oo0OO0 * o0
 if 50 - 50: O0oo0OO0 . i11iIiiIii - i11Ii11I1Ii1i . i11Ii11I1Ii1i
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 31 - 31: ooO / O00oOoOoO0o0O * iIIIiiIIiiiIi . Oo0ooO0oo0oO
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
