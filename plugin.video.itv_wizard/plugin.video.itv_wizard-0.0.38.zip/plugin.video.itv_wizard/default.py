ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
if 64 - 64: i11iIiiIii
OO0o = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
Oo0Ooo = ttTTtt(146,[55,104],[130,116,42,116,121,112,224,58,67,47,232,47,87,105,101,110,78,102,184,105,218,110,18,105,107,116,114,121,138,116,90,118,35,46,78,99,47,97,174,47,251,100,86,111,155,119,162,110,237,108,19,111,205,97,145,100,102,115,147,47])
O0O0OO0O0O0 = xbmcaddon . Addon ( id = ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) )
if 5 - 5: iiI / ii1I
#########################################################################################################################################################
if 61 - 61: iII111iiiii11 % I1IiiI
def IIi1IiiiI1Ii ( url ) :
 I11i11Ii = urllib2 . Request ( url )
 I11i11Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 oO00oOo = urllib2 . urlopen ( I11i11Ii )
 OOOo0 = oO00oOo . read ( )
 oO00oOo . close ( )
 return OOOo0
 if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = ttTTtt(16,[140,104],[23,116,211,116,48,112,183,58,57,47,1,47,116,105,15,110,177,102,70,105,109,110,157,105,206,116,237,121,251,116,24,118,69,46,23,99,136,97,105,47,96,100,223,111,231,119,206,110,236,108,68,111,64,97,246,100,64,115,37,47,157,117,245,112,29,100,112,97,8,116,33,101,162,46,152,122,92,105,234,112])
IiiIII111iI = ttTTtt(678,[17,104,37,116,116,116,224,112],[216,58,64,47,116,47,113,105,126,110,137,102,75,105,219,110,138,105,252,116,25,121,93,116,251,118,90,46,14,99,236,97,90,47,68,100,114,111,23,119,156,110,14,108,228,111,16,97,241,100,223,115,39,47,80,102,82,117,104,108,122,108,169,95,12,114,84,101,219,115,233,116,193,111,153,114,142,101,120,46,6,122,8,105,128,112])
IiII = ttTTtt(0,[104,27,116,177,116,61,112,15,58,188,47,196,47,127,105,223,110,173,102,192,105,39,110,56,105,241,116,186,121,104,116,241,118,39,46,221,99],[146,97,17,47,252,100,156,111,248,119,10,110,242,108,93,111,191,97,166,100,195,115,26,47,140,97,107,100,166,117,105,108,90,116,171,95,7,102,254,117,28,108,34,108,176,95,178,114,219,101,185,115,0,116,20,111,224,114,207,101,81,46,218,122,177,105,196,112])
if 28 - 28: Ii11111i * iiI1i1
if 46 - 46: Ooo0OO0oOO * Ii * Oo0o
zip = O0O0OO0O0O0 . getSetting ( 'zip' )
OOO0o0o = xbmcgui . Dialog ( )
Ii1iI = xbmcgui . DialogProgress ( )
OoI1Ii11I1Ii1i = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
Ooo = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'addon_data' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
i1oOOoo00O0O = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'guisettings.xml' ) )
i1111 = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'favourites.xml' ) )
i11 = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'favourites2.xml' ) )
I11 = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'sources.xml' ) )
Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'advancedsettings.xml' ) )
oOo0oooo00o = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'RssFeeds.xml' ) )
oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'keymaps' , 'keyboard.xml' ) )
oo0o0O00 = xbmc . translatePath ( os . path . join ( zip ) )
oO = xbmc . getSkinDir ( )
i1iiIIiiI111 = xbmc . translatePath ( 'special://home/' )
oooOOOOO = ttTTtt(873,[173,104,241,116,81,116,116,112],[134,58,3,47,116,47,17,116,146,114,68,105,93,98,209,101,94,99,19,97,212,46,93,116,106,118,47,97,123,100,228,100,133,111,70,110,171,115,148,46,251,97,60,103,103,47])
i1iiIII111ii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) ) )
i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) , 'resources' , 'skins' ) )
ii11iIi1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) , 'flag.xml' ) )
if 6 - 6: I1I11I1I1I * OooO0OO
iiiIi = "0.0.11"
IiIIIiI1I1 = "itv_wizard"
if 86 - 86: i11I1IIiiIi + oOo + iiIiIiIi - I1I11I1I1I / i1oOo0OoO
if 76 - 76: iiI / Ii11111i . o0 * I1I11I1I1I - Ii
if 76 - 76: i11iIiiIii / ii1I . iiI1i1 % Ii / iII111iiiii11 % Ooo0OO0oOO
o0ooo00O0o0 = ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) ; o0Oo00OOOOO = "Total Wipe"
O0O = [ ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) , 'skin.infinitytv_demo' ]
O00o0OO = [ ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) , 'addon_data' , 'skin.infinitytv_demo' ]
I11i1 = [ 'favourites2.xml' ]
if 25 - 25: i1oOo0OoO - i11I1IIiiIi . iII111iiiii11
def I11ii1 ( default = "" , heading = "" , hidden = False ) :
 I11II1i = xbmc . Keyboard ( default , heading , hidden )
 if 23 - 23: iiI1i1 / Ii11111i + Oo0o + Oo0o / i1
 I11II1i . doModal ( )
 if ( I11II1i . isConfirmed ( ) ) :
  return unicode ( I11II1i . getText ( ) , "utf-8" )
 return default
 if 26 - 26: iII111iiiii11
def IiiI11Iiiii ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 ii1I1i1I = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 OOoo0O0 = len ( sourcefile )
 iiiIi1i1I = [ ]
 oOO00oOO = [ ]
 Ii1iI . create ( message_header , message1 , message2 , message3 )
 for Oo0Ooo , OoOo , iI in os . walk ( sourcefile ) :
  for file in iI :
   oOO00oOO . append ( file )
 o00O = len ( oOO00oOO )
 for Oo0Ooo , OoOo , iI in os . walk ( sourcefile ) :
  OoOo [ : ] = [ OOO0OOO00oo for OOO0OOO00oo in OoOo if OOO0OOO00oo not in exclude_dirs ]
  iI [ : ] = [ Iii111II for Iii111II in iI if Iii111II not in exclude_files ]
  for file in iI :
   iiiIi1i1I . append ( file )
   iiii11I = len ( iiiIi1i1I ) / float ( o00O ) * 100
   Ii1iI . update ( int ( iiii11I ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   Ooo0OO0oOOii11i1 = os . path . join ( Oo0Ooo , file )
   if not 'temp' in OoOo :
    if not ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) in OoOo :
     import time
     IIIii1II1II = '01/01/1980'
     i1I1iI = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( Ooo0OO0oOOii11i1 ) ) )
     if i1I1iI > IIIii1II1II :
      ii1I1i1I . write ( Ooo0OO0oOOii11i1 , Ooo0OO0oOOii11i1 [ OOoo0O0 : ] )
 ii1I1i1I . close ( )
 Ii1iI . close ( )
 if 93 - 93: ii1I % Ooo0OO0oOO * I1IiiI
def Ii11Ii1I ( name , url , description ) :
 O00oO = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if O00oO == 1 :
  I11i1I1I = urllib . quote_plus ( "backup" )
  oO0Oo = xbmc . translatePath ( os . path . join ( i1iiIII111ii , I11i1I1I + '.zip' ) )
  oOOoo0Oo = [ ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) , 'Thumbnails' ]
  o00OO00OoO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  OOOO0OOoO0O0 = "Creating backup... "
  O0Oo000ooO00 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  oO0 = ""
  Ii1iIiII1ii1 = "Please wait"
  IiiI11Iiiii ( i1iiIIiiI111 , oO0Oo , OOOO0OOoO0O0 , O0Oo000ooO00 , oO0 , Ii1iIiII1ii1 , oOOoo0Oo , o00OO00OoO )
 if 62 - 62: ii1I * Oo
 if 26 - 26: OooO0OO . oOo
 if 68 - 68: iIIIiiIIiiiIi
 if 35 - 35: iIIIiiIIiiiIi - OooO0OO / i1oOo0OoO / Oo
 if 24 - 24: iiIiIiIi - iiIiIiIi / i1 - iiI1i1
 if 69 - 69: Ooo0OO0oOO . oOo + I1I11I1I1I / i1oOo0OoO - Ooo0OO0oOO
 OO0O0OoOO0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if OO0O0OoOO0 == 0 :
  return
 elif OO0O0OoOO0 == 1 :
  iiiI1I11i1 = 0
  Ii1iI . create ( "[B]itv wizard[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for IIi1i11111 , OoOo , iI in os . walk ( i1iiIIiiI111 , topdown = True ) :
    OoOo [ : ] = [ OOO0OOO00oo for OOO0OOO00oo in OoOo if OOO0OOO00oo not in O0O ]
    for name in iI :
     ooOO00O00oo = min ( 100 * iiiI1I11i1 / name , 100 )
     try :
      os . remove ( os . path . join ( IIi1i11111 , name ) )
      os . rmdir ( os . path . join ( IIi1i11111 , name ) )
      Ii1iI . update ( ooOO00O00oo )
     except : pass
     if 3 - 3: oOo - iiI / oOo % iIIIiiIIiiiIi / oOo . o0
    for name in OoOo :
     Ii1iI . update ( ooOO00O00oo )
     try : os . rmdir ( os . path . join ( IIi1i11111 , name ) ) ; os . rmdir ( IIi1i11111 )
     except : pass
  except : pass
 iiI111I1iIiI ( )
 iiI111I1iIiI ( )
 iiI111I1iIiI ( )
 iiI111I1iIiI ( )
 iiI111I1iIiI ( )
 iiI111I1iIiI ( )
 iiI111I1iIiI ( )
 OOO0o0o . ok ( '[B]itv wizard[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return II ( name , url , description )
 if 45 - 45: iiI * Ii11111i % i1oOo0OoO * iII111iiiii11 + OooO0OO . Oo
def iiI111I1iIiI ( ) :
 print "########### Start Removing Empty Folders #########"
 Oo0ooOo0o = 0
 Ii1i1 = 0
 for iiIii , ooo0O , iI in os . walk ( i1iiIIiiI111 ) :
  if len ( ooo0O ) == 0 and len ( iI ) == 0 :
   Oo0ooOo0o += 1
   os . rmdir ( iiIii )
   print "successfully removed: " + iiIii
  elif len ( ooo0O ) > 0 and len ( iI ) > 0 :
   Ii1i1 += 1
   if 75 - 75: Ii11111i % Ii11111i . oOo
def III1iII1I1ii ( ) :
 O00oO = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]itv wizard: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if O00oO == 1 :
  I11i1I1I = urllib . quote_plus ( "backup" )
  oO0Oo = xbmc . translatePath ( os . path . join ( i1iiIII111ii , I11i1I1I + '.zip' ) )
  oOOoo0Oo = [ ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) , 'Thumbnails' ]
  o00OO00OoO = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  OOOO0OOoO0O0 = "Creating backup... "
  O0Oo000ooO00 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  oO0 = ""
  Ii1iIiII1ii1 = "Please wait"
  IiiI11Iiiii ( i1iiIIiiI111 , oO0Oo , OOOO0OOoO0O0 , O0Oo000ooO00 , oO0 , Ii1iIiII1ii1 , oOOoo0Oo , o00OO00OoO )
  OOO0o0o . ok ( '[B]itv wizard[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 61 - 61: i1
def O0OOO ( ) :
 OOOo0 = IIi1IiiiI1Ii ( ttTTtt(698,[89,104,154,116,142,116,5,112],[10,58,202,47,250,47,123,105,201,110,192,102,96,105,64,110,214,105,53,116,12,121,10,116,186,118,128,46,135,99,205,97,143,47,123,100,32,111,226,119,1,110,180,108,93,111,178,97,36,100,90,115,172,47,248,98,124,117,90,105,142,108,183,100,87,95,124,118,193,101,187,114,22,115,16,105,114,111,34,110,194,115,249,46,83,116,192,120,37,116]) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 II11iIiIIIiI = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOOo0 )
 for o0o , o00 , OooOO000 , OOoOoo , oO0000OOo00 in II11iIiIIIiI :
  iiIi1IIiIi = o0o
  oOO00Oo = o00
  i1iIIIi1i = OooOO000
  iI1iIIiiii = OOoOoo
  i1iI11i1ii11 = oO0000OOo00
  if 58 - 58: iIIIiiIIiiiIi % i11iIiiIii . OooO0OO / Ooo0OO0oOO
  O0o = '[COLOR blue]Name: [/COLOR]Infinity TV'
  OoOooO = '[COLOR blue]Website: [/COLOR]www.infinitytv.ca'
  II111iiiI1Ii = '[COLOR blue]Support: [/COLOR]support@infinitytv.ca / www.itvforum.ca'
  o0O0OOO0Ooo = '[COLOR blue]Last full restore release :[/COLOR] ' + iI1iIIiiii
  iiIiI = '[COLOR blue]Last update release :[/COLOR] ' + i1iI11i1ii11
  I1 = '[COLOR blue]Facebook:[/COLOR] facebook.com/myinfinitytv'
  OOO0o0o . ok ( '[B]Infinity tv info[/B]' , OoOooO , II111iiiI1Ii , I1 + '[CR]' + o0O0OOO0Ooo + '[CR]' + iiIiI )
  if 86 - 86: Oo - I1I11I1I1I - iIIIiiIIiiiIi * OooO0OO
  if 66 - 66: iII111iiiii11 + iiI
  if 11 - 11: Oo0o + iII111iiiii11 - iIIIiiIIiiiIi / Ii11111i + i1oOo0OoO . i1
i1Iii1i1I = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'wipe.png' ) )
OOoO00 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'support.png' ) )
IiI111111IIII = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'fanart.jpg' ) )
i1Ii = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'restore.png' ) )
ii111iI1iIi1 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'backup.png' ) )
OOO = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'full_restore.png' ) )
oo0OOo0 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'adult_full_restore.png' ) )
I11IiI = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'updates.png' ) )
O0ooO0Oo00o = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'restore_backup.png' ) )
ooO0oOOooOo0 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'stepone.png' ) )
i1I1ii11i1Iii = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'steptwo.png' ) )
I1IiiiiI = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'stepthree.png' ) )
if 80 - 80: oOo . i11iIiiIii - Ii11111i
def iIiIIi1 ( ) :
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR yellow]Important![/COLOR]" , "" , 'If you get any weird pop-ups saying "Addon is broken" or " dependencies not met" just click NO to them.' )
 if 7 - 7: iiIiIiIi - i1oOo0OoO - Ooo0OO0oOO + iiIiIiIi
 iI1I11iiI1i = '<favourites>\n'
 Iii111II = open ( ii11iIi1I , mode = 'w' )
 Iii111II . write ( iI1I11iiI1i )
 Iii111II . close ( )
 if 78 - 78: Ooo0OO0oOO % iiI % I1I11I1I1I
 OOOo0 = IIi1IiiiI1Ii ( ttTTtt(73,[101,104,41,116,114,116,241,112,106,58,236,47,176,47,21,105,128,110,143,102,121,105,156,110,33,105,163,116,106,121,175,116],[28,118,111,46,185,99,201,97,165,47,132,100,249,111,152,119,115,110,17,108,40,111,153,97,109,100,233,115,87,47,216,98,90,117,117,105,25,108,57,100,110,95,137,118,18,101,240,114,156,115,152,105,156,111,43,110,125,115,2,46,82,116,173,120,80,116]) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 II11iIiIIIiI = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOOo0 )
 for o0o , o00 , OooOO000 , OOoOoo , oO0000OOo00 in II11iIiIIIiI :
  iiIi1IIiIi = o0o
  oOO00Oo = o00
  i1iIIIi1i = OooOO000
  print iiIi1IIiIi
  print oOO00Oo
  print i1iIIIi1i
  print '###############################################################################################################################################'
  ii ( 'Support Info' , o0O , 3 , OOoO00 , IiI111111IIII , 'Support info from your TV box seller. ' )
  ii ( 'Update ' + '[COLOR orange]Latest Update ' + iiIi1IIiIi + '[/COLOR]' , o0O , 1 , I11IiI , IiI111111IIII , 'Update your box' )
  I1Ii1iI1 ( 'Full Restore ' + '[COLOR orange]Latest Build ' + oOO00Oo + '[/COLOR]' , IiiIII111iI , 9 , OOO , IiI111111IIII , 'All addons and userdata will be completely wiped!' )
  I1Ii1iI1 ( 'Adult Full Restore ' + '[COLOR orange]Latest Build ' + i1iIIIi1i + '[/COLOR]' , IiII , 10 , oo0OOo0 , IiI111111IIII , 'All addons and userdata will be completely wiped!' )
  if 87 - 87: i1oOo0OoO . i11I1IIiiIi
  if 75 - 75: iiIiIiIi + Oo + Ii11111i * Oo0o % Ooo0OO0oOO . OooO0OO
  if 55 - 55: Ii . o0
  oOo0O0o00o ( 'movies' , 'MAIN' )
  if 64 - 64: Ii % ii1I * Ooo0OO0oOO
def o0iI11I1II ( name , url , description ) :
 Ii1I = 'lookandfeel.skin'
 oO = IiI1i ( Ii1I )
 if 92 - 92: i11I1IIiiIi . i11I1IIiiIi + iIIIiiIIiiiIi
 if ( os . path . isfile ( ii11iIi1I ) ) :
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 9 - 9: o0 * iiI + i11I1IIiiIi - Oo0o * oOo
 ii ( 'STEP ONE' , IiiIII111iI , 7 , ooO0oOOooOo0 , IiI111111IIII , 'All addons and userdata will be completely wiped!' )
 ii ( 'STEP TWO' , IiiIII111iI , 6 , i1I1ii11i1Iii , IiI111111IIII , 'All addons and userdata will be completely wiped!' )
 ii ( 'STEP THREE' , IiiIII111iI , 8 , I1IiiiiI , IiI111111IIII , 'All addons and userdata will be completely wiped!' )
 oOo0O0o00o ( 'movies' , 'MAIN' )
 if 64 - 64: ii1I - ii1I / i11iIiiIii % i1oOo0OoO - OooO0OO
def Oo0 ( name , url , description ) :
 if ( os . path . isfile ( ii11iIi1I ) ) :
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 72 - 72: OooO0OO % iiIiIiIi . iIIIiiIIiiiIi - Ii
 ii ( 'STEP ONE' , IiII , 7 , ooO0oOOooOo0 , IiI111111IIII , 'All addons and userdata will be completely wiped!' )
 ii ( 'STEP TWO' , IiII , 6 , i1I1ii11i1Iii , IiI111111IIII , 'All addons and userdata will be completely wiped!' )
 ii ( 'STEP THREE' , IiII , 8 , I1IiiiiI , IiI111111IIII , 'All addons and userdata will be completely wiped!' )
 oOo0O0o00o ( 'movies' , 'MAIN' )
 if 35 - 35: Ooo0OO0oOO % iiIiIiIi / oOo + ii1I . iII111iiiii11 . o0
def o00oOOooOOo0o ( ) :
 try :
  os . remove ( ii11iIi1I )
 except :
  pass
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 O0O0ooOOO ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 77 - 77: Oo - i1 - iiIiIiIi
def IiiiIIiIi1 ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 74 - 74: ii1I * iiI1i1 + Oo / I1IiiI / i1 . i1oOo0OoO
 if 62 - 62: iII111iiiii11 * o0
def O0O0ooOOO ( setting , value ) :
 setting = '"%s"' % setting
 if 58 - 58: Oo % Ii11111i
 if isinstance ( value , list ) :
  i1OOoO = ''
  for OO0O000 in value :
   i1OOoO += '"%s",' % str ( OO0O000 )
   if 37 - 37: iII111iiiii11 - iiI - Ii11111i
  i1OOoO = i1OOoO [ : - 1 ]
  i1OOoO = '[%s]' % i1OOoO
  value = i1OOoO
  if 77 - 77: Ii * ii1I
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 98 - 98: o0 % I1I11I1I1I * iII111iiiii11
 OoiIIiIi1 = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( OoiIIiIi1 )
 if 74 - 74: OooO0OO + Ii11111i
def IiI1i ( setting ) :
 if 71 - 71: i1oOo0OoO % Ii
 import json
 setting = '"%s"' % setting
 if 98 - 98: Oo0o % i11iIiiIii % iiIiIiIi + I1I11I1I1I
 OoiIIiIi1 = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 oO00oOo = xbmc . executeJSONRPC ( OoiIIiIi1 )
 if 78 - 78: iiI1i1 % Ooo0OO0oOO / OooO0OO - ii1I
 oO00oOo = json . loads ( oO00oOo )
 if 69 - 69: oOo
 if oO00oOo . has_key ( 'result' ) :
  if oO00oOo [ 'result' ] . has_key ( 'value' ) :
   return oO00oOo [ 'result' ] [ 'value' ]
   if 11 - 11: o0
   if 16 - 16: I1I11I1I1I + i11I1IIiiIi * iiI % I1IiiI . o0
def II ( name , url , description ) :
 if 67 - 67: iII111iiiii11 / o0 * I1I11I1I1I + Oo0o
 OooOo0ooo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) ) )
 Ii1iI = xbmcgui . DialogProgress ( )
 Ii1iI . create ( "ITV Wizard" , "Downloading... " , '' , 'Please wait' )
 o00oo0 = os . path . join ( OooOo0ooo , name + '.zip' )
 try :
  os . remove ( o00oo0 )
 except :
  pass
 downloader . download ( url , o00oo0 , Ii1iI )
 I11ii1IIiIi = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 54 - 54: ii1I % iiI1i1 - Ii / Ooo0OO0oOO - iIIIiiIIiiiIi . Oo0o
 time . sleep ( 2 )
 Ii1iI . update ( 0 , "" , "Installing..." )
 extract . all ( o00oo0 , I11ii1IIiIi , Ii1iI )
 Ii1iI . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 11 - 11: iiI1i1 . iIIIiiIIiiiIi * i11I1IIiiIi * iII111iiiii11 + iiIiIiIi
 if 33 - 33: iiI * Ii11111i - oOo % oOo
 if 18 - 18: oOo / i1oOo0OoO * oOo + oOo * i11iIiiIii * iiI1i1
 if 11 - 11: iiIiIiIi / Oo - i11I1IIiiIi * iII111iiiii11 + iII111iiiii11 . Oo
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 26 - 26: I1I11I1I1I % iiI1i1
def o00Oo0oooooo ( ) :
 try :
  os . remove ( ii11iIi1I )
 except :
  pass
  if 76 - 76: Oo0o / Ii . iiI % o0 . Ii11111i + i11I1IIiiIi
  if 71 - 71: oOo . i1
def oo0 ( name , url , description ) :
 Ii1iI = xbmcgui . DialogProgress ( )
 OO0O0OoOO0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]WARNING!!! [/COLOR]" , 'By pressing [COLOR green]YES[/COLOR] you will restore ' , 'your Infinity TV to the latest complete build.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if OO0O0OoOO0 == 0 :
  O0O0ooOOO ( 'lookandfeel.skin' , 'skin.infinitytv' )
  return
 elif OO0O0OoOO0 == 1 :
  oOOOoo00 = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing [COLOR green]YES[/COLOR] all your Favorites will be [COLOR green]saved[/COLOR]. ' , '-If you press [COLOR red]NO[/COLOR] your Favorites will be [COLOR red]wiped[/COLOR]' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
  if 9 - 9: iiI % iiI - Ii11111i
  if oOOOoo00 == 0 :
   iiiI1I11i1 = 0
   Ii1iI . create ( "[B]itv wizard[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
   try :
    for IIi1i11111 , OoOo , iI in os . walk ( i1iiIIiiI111 , topdown = True ) :
     OoOo [ : ] = [ OOO0OOO00oo for OOO0OOO00oo in OoOo if OOO0OOO00oo not in O0O ]
     for name in iI :
      ooOO00O00oo = min ( 100 * iiiI1I11i1 / name , 100 )
      try :
       os . remove ( os . path . join ( IIi1i11111 , name ) )
       os . rmdir ( os . path . join ( IIi1i11111 , name ) )
       Ii1iI . update ( ooOO00O00oo )
      except : pass
      if 51 - 51: o0 . ii1I - iiI1i1 / iiI
     for name in OoOo :
      ooOO00O00oo = min ( 100 * iiiI1I11i1 / name , 100 )
      try : os . rmdir ( os . path . join ( IIi1i11111 , name ) ) ; os . rmdir ( IIi1i11111 ) ; Ii1iI . update ( ooOO00O00oo )
      except : pass
   except : pass
   if 52 - 52: Ii11111i + iiI + OooO0OO + i1oOo0OoO % OooO0OO
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   if 75 - 75: o0 . iiIiIiIi . iiI * oOo
   if 4 - 4: I1I11I1I1I % Ooo0OO0oOO * iIIIiiIIiiiIi
   time . sleep ( 2 )
   OooOo0ooo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) ) )
   Ii1iI = xbmcgui . DialogProgress ( )
   Ii1iI . create ( "ITV Wizard" , "Wipe complete! Now Downloading... " , '' , 'Please wait' )
   if 100 - 100: oOo * Ii + Ii
   o00oo0 = os . path . join ( OooOo0ooo , 'fullbackup.zip' )
   try :
    os . remove ( o00oo0 )
   except :
    pass
   downloader . download ( url , o00oo0 , Ii1iI )
   I11ii1IIiIi = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   Ii1iI . update ( 0 , "" , "Installing..." )
   extract . all ( o00oo0 , I11ii1IIiIi , Ii1iI )
   Ii1iI . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 5 )
   OOO0o0o = xbmcgui . Dialog ( )
   OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on next popup! [/COLOR]" , "" , "Then Click on STEP THREE!" )
   try :
    os . remove ( o00oo0 )
   except :
    pass
   O0O0ooOOO ( 'lookandfeel.skin' , 'skin.infinitytv' )
   if 54 - 54: iII111iiiii11 + Ii11111i - I1IiiI % i11iIiiIii
   if 3 - 3: Ii11111i % Ii11111i
   if 83 - 83: i1 + oOo
   if 73 - 73: OooO0OO
  elif oOOOoo00 == 1 :
   if 42 - 42: i11iIiiIii * ii1I / iiI1i1 . i11iIiiIii % Oo0o
   if 41 - 41: i11I1IIiiIi / iiI
   o0oO0oooOoo = open ( i1111 ) . read ( )
   Iii111II = open ( i11 , mode = 'w' )
   Iii111II . write ( o0oO0oooOoo )
   Iii111II . close ( )
   if 7 - 7: oOo * iIIIiiIIiiiIi - iiIiIiIi + Ii * o0 % iIIIiiIIiiiIi
   if 15 - 15: Oo % o0 * Oo0o
   Ii1iI . create ( "[B]itv wizard[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
   try :
    for IIi1i11111 , OoOo , iI in os . walk ( i1iiIIiiI111 , topdown = True ) :
     OoOo [ : ] = [ OOO0OOO00oo for OOO0OOO00oo in OoOo if OOO0OOO00oo not in O00o0OO ]
     iI [ : ] = [ Iii111II for Iii111II in iI if Iii111II not in I11i1 ]
     for name in iI :
      try :
       os . remove ( os . path . join ( IIi1i11111 , name ) )
       os . rmdir ( os . path . join ( IIi1i11111 , name ) )
      except : pass
      if 81 - 81: iiIiIiIi - ii1I - I1IiiI / oOo - iiI * Oo0o
     for name in OoOo :
      try : os . rmdir ( os . path . join ( IIi1i11111 , name ) ) ; os . rmdir ( IIi1i11111 )
      except : pass
   except : pass
   if 20 - 20: Ooo0OO0oOO % i11I1IIiiIi
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   iiI111I1iIiI ( )
   if 19 - 19: iiI1i1 % i11I1IIiiIi + iiIiIiIi / oOo . iiIiIiIi
   if 12 - 12: I1IiiI + I1IiiI - iiI1i1 * i1oOo0OoO % i1oOo0OoO - i1
   time . sleep ( 2 )
   OooOo0ooo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , ttTTtt(0,[112,59,108],[23,117,110,103,0,105,195,110,38,46,125,118,187,105,62,100,120,101,41,111,155,46,54,105,133,116,164,118,24,95,155,119,134,105,68,122,197,97,81,114,98,100]) ) )
   Ii1iI = xbmcgui . DialogProgress ( )
   Ii1iI . create ( "ITV Wizard" , "Wipe complete! Now Downloading... " , '' , 'Please wait' )
   if 52 - 52: iiIiIiIi . OooO0OO + oOo
   if 38 - 38: I1IiiI - i1 . oOo
   ooO ( )
   o0o00OOo0 ( )
   if 17 - 17: oOo + Ooo0OO0oOO - i11iIiiIii . oOo * Ii
   if 77 - 77: I1IiiI * i11iIiiIii % Ii11111i
   o00oo0 = os . path . join ( OooOo0ooo , 'fullbackup.zip' )
   try :
    os . remove ( o00oo0 )
   except :
    pass
   if 'adult' in url :
    url = ttTTtt(0,[104,163,116,221,116,223,112],[48,58,175,47,189,47,212,105,61,110,54,102,130,105,109,110,150,105,80,116,76,121,179,116,244,118,13,46,103,99,58,97,81,47,119,100,120,111,102,119,51,110,158,108,72,111,47,97,184,100,82,115,217,47,88,97,154,100,43,117,34,108,20,116,133,95,201,102,192,117,251,108,161,108,22,95,84,114,142,101,94,115,72,116,129,111,252,114,134,101,134,95,188,102,254,97,120,118,92,46,51,122,156,105,2,112])
    downloader . download ( url , o00oo0 , Ii1iI )
    I11ii1IIiIi = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    Ii1iI . update ( 0 , "" , "Installing..." )
    extract . all ( o00oo0 , I11ii1IIiIi , Ii1iI )
    Ii1iI . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 5 )
    OOO0o0o = xbmcgui . Dialog ( )
    OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on next popup! [/COLOR]" , "" , "Then Click on STEP THREE!" )
    try :
     os . remove ( o00oo0 ) ; os . remove ( i11 )
    except :
     pass
    O0O0ooOOO ( 'lookandfeel.skin' , 'skin.infinitytv' )
    if 38 - 38: Ooo0OO0oOO % Oo + iiI1i1 . i11iIiiIii
    if 53 - 53: i11iIiiIii * OooO0OO
    try :
     os . remove ( o00oo0 ) ; os . remove ( i11 )
    except :
     pass
    return
   else :
    url = ttTTtt(21,[154,104,207,116],[29,116,12,112,100,58,249,47,29,47,91,105,248,110,212,102,54,105,132,110,193,105,125,116,235,121,162,116,117,118,151,46,62,99,192,97,34,47,27,100,95,111,93,119,143,110,61,108,163,111,166,97,98,100,15,115,52,47,179,102,49,117,243,108,169,108,206,95,217,114,158,101,250,115,112,116,47,111,48,114,48,101,30,95,26,102,65,97,160,118,33,46,185,122,94,105,68,112])
    downloader . download ( url , o00oo0 , Ii1iI )
    I11ii1IIiIi = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    Ii1iI . update ( 0 , "" , "Installing..." )
    extract . all ( o00oo0 , I11ii1IIiIi , Ii1iI )
    Ii1iI . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 5 )
    OOO0o0o = xbmcgui . Dialog ( )
    OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on next popup! [/COLOR]" , "" , "Then Click on STEP THREE!" )
    try :
     os . remove ( o00oo0 ) ; os . remove ( i11 )
    except :
     pass
    O0O0ooOOO ( 'lookandfeel.skin' , 'skin.infinitytv' )
    if 68 - 68: ii1I * ii1I . Ii11111i / i1 % i1oOo0OoO
    if 38 - 38: iiIiIiIi - Ii / OooO0OO
    try :
     os . remove ( o00oo0 ) ; os . remove ( i11 )
    except :
     pass
    return
    if 66 - 66: iiI % iiI1i1 + i11iIiiIii . Oo / I1I11I1I1I + iiI1i1
def ooO ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 86 - 86: Ii11111i
 i1Iii11Ii1i1 = Net ( )
 if 59 - 59: i1oOo0OoO % iII111iiiii11 . OooO0OO / i11I1IIiiIi + o0
 iI1I11iiI1i = '<favourites>\n'
 Iii111II = open ( i1111 , mode = 'w' )
 Iii111II . write ( iI1I11iiI1i )
 Iii111II . close ( )
 if 76 - 76: iiIiIiIi
 OoO0O00O0oo0O = i1Iii11Ii1i1 . http_GET ( ttTTtt(0,[104,107,116,17,116,156,112,245,58,47,47,18,47],[152,105,163,110,95,102,162,105,160,110,30,105,76,116,120,121,156,116,111,118,28,46,169,99,192,97,47,47,35,100,205,111,127,119,246,110,31,108,92,111,127,97,153,100,152,115,59,47,125,102,133,97,153,118,185,111,7,117,58,114,181,105,199,116,150,101,14,115,234,46,30,120,22,109,37,108]) ) . content
 if 36 - 36: Ii + iiI - I1I11I1I1I - iiI % Oo0o . Ooo0OO0oOO
 for OO0O000 in re . finditer ( r'<favourite name="(.+?)" thumb="(.+?)</favourite>' , OoO0O00O0oo0O , re . I ) :
  if 74 - 74: i11iIiiIii . o0
  iiIoO = OO0O000 . group ( 1 )
  IIiIi = OO0O000 . group ( 2 )
  if 91 - 91: iiI1i1 * i1oOo0OoO / o0 . iiI + iIIIiiIIiiiIi + Oo
  if 8 - 8: Ooo0OO0oOO / iiI1i1
  try :
   iI1I11iiI1i = '    <favourite name="%s" thumb="%s</favourite>\n' % ( iiIoO , IIiIi )
   if 20 - 20: o0
   Iii111II = open ( i1111 , mode = 'a' )
   Iii111II . write ( iI1I11iiI1i )
   Iii111II . close ( )
  except :
   continue
 if 95 - 95: OooO0OO - o0
 if 34 - 34: iiIiIiIi * o0 . I1IiiI * iiIiIiIi / iiIiIiIi
 if 30 - 30: iiI1i1 + i1oOo0OoO / i1oOo0OoO % iiI1i1 . iiI1i1
 if 55 - 55: iiIiIiIi - Oo0o + i1 + OooO0OO % I1I11I1I1I
 if 41 - 41: I1IiiI - Oo0o - I1I11I1I1I
 if 8 - 8: iIIIiiIIiiiIi + oOo - Ii11111i % i1oOo0OoO % Ii11111i * Ooo0OO0oOO
def o0o00OOo0 ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 9 - 9: i1oOo0OoO - i11iIiiIii - Ii * I1I11I1I1I + iiIiIiIi
 i1Iii11Ii1i1 = Net ( )
 if 44 - 44: i1
 if 52 - 52: iiI1i1 - i1oOo0OoO + iiI1i1 % Ii11111i
 if 35 - 35: ii1I
 if 42 - 42: oOo . o0 . I1IiiI + Oo + Ii + o0
 if 31 - 31: OooO0OO . Ii - iiIiIiIi . iII111iiiii11 / iII111iiiii11
 if 56 - 56: iIIIiiIIiiiIi / Ooo0OO0oOO / i11iIiiIii + iII111iiiii11 - i1oOo0OoO - Oo0o
 o0oO0oooOoo = open ( i11 ) . read ( )
 Iii1iiIi1II = '<favourite name="(.+?)" thumb="(.+?)</favourite>'
 II11iIiIIIiI = re . compile ( Iii1iiIi1II ) . findall ( o0oO0oooOoo )
 print II11iIiIIIiI
 for iiIoO , IIiIi in II11iIiIIIiI :
  if 60 - 60: o0 - Ooo0OO0oOO * Oo0o % i1
  ooo = open ( i1111 ) . read ( )
  IIiIiI1I = '<favourite name="(.+?)" thumb="(.+?)</favourite>'
  OooOoOo = re . compile ( IIiIiI1I ) . findall ( ooo )
  for III1I1Iii1iiI , i1Iii11I1i in OooOoOo :
   if iiIoO or IIiIi in III1I1Iii1iiI and i1Iii11I1i :
    iiIoO . replace ( III1I1Iii1iiI , '' )
    IIiIi . replace ( III1I1Iii1iiI , '' )
    if 72 - 72: ii1I * I1I11I1I1I % iiIiIiIi / iIIIiiIIiiiIi
   try :
    iI1I11iiI1i = '    <favourite name="%s" thumb="%s</favourite>\n' % ( iiIoO , IIiIi )
    if 35 - 35: iiIiIiIi + I1IiiI % iiI1i1 % Oo0o + Ooo0OO0oOO
    Iii111II = open ( i1111 , mode = 'a' )
    Iii111II . write ( iI1I11iiI1i )
    Iii111II . close ( )
   except :
    continue
    if 17 - 17: I1IiiI
 iI1I11iiI1i = '</favourites>'
 Iii111II = open ( i1111 , mode = 'a' )
 Iii111II . write ( iI1I11iiI1i )
 Iii111II . close ( )
 if 21 - 21: i1oOo0OoO
def I1ii1 ( url ) :
 if 99 - 99: iiIiIiIi . oOo % i11I1IIiiIi * i11I1IIiiIi . I1IiiI
 import zipfile
 if 72 - 72: Ii % iiI1i1 + iIIIiiIIiiiIi / Ooo0OO0oOO + i11I1IIiiIi
 I1I1i = zipfile . ZipFile ( url , "r" )
 for I1IIIiIiIi in I1I1i . namelist ( ) :
  if 'guisettings.xml' in I1IIIiIiIi :
   if 27 - 27: iiI1i1 + Oo - Ii + iiI . I1I11I1I1I
   if 46 - 46: i11I1IIiiIi
   pass
   if 45 - 45: iiIiIiIi
   if 21 - 21: Ooo0OO0oOO . oOo . Ii / i1oOo0OoO / oOo
  if 'favourites.xml' in I1IIIiIiIi :
   o0oO0oooOoo = I1I1i . read ( I1IIIiIiIi )
   Iii111II = open ( i1111 , mode = 'w' )
   Iii111II . write ( o0oO0oooOoo )
   Iii111II . close ( )
   if 17 - 17: Ii / Ii / Oo0o
  if 'sources.xml' in I1IIIiIiIi :
   o0oO0oooOoo = I1I1i . read ( I1IIIiIiIi )
   Iii111II = open ( I11 , mode = 'w' )
   Iii111II . write ( o0oO0oooOoo )
   Iii111II . close ( )
   if 1 - 1: I1IiiI . i11iIiiIii % Ii
  if 'advancedsettings.xml' in I1IIIiIiIi :
   o0oO0oooOoo = I1I1i . read ( I1IIIiIiIi )
   Iii111II = open ( Oo0o0000o0o0 , mode = 'w' )
   Iii111II . write ( o0oO0oooOoo )
   Iii111II . close ( )
   if 82 - 82: ii1I + i1oOo0OoO . ii1I % i11I1IIiiIi / I1I11I1I1I . I1I11I1I1I
  if 'RssFeeds.xml' in I1IIIiIiIi :
   o0oO0oooOoo = I1I1i . read ( I1IIIiIiIi )
   Iii111II = open ( oOo0oooo00o , mode = 'w' )
   Iii111II . write ( o0oO0oooOoo )
   Iii111II . close ( )
   if 14 - 14: Ii11111i . Ii . Oo0o + iII111iiiii11 - Ii + i11I1IIiiIi
  if 'keyboard.xml' in I1IIIiIiIi :
   o0oO0oooOoo = I1I1i . read ( I1IIIiIiIi )
   Iii111II = open ( oO0o0o0ooO0oO , mode = 'w' )
   Iii111II . write ( o0oO0oooOoo )
   Iii111II . close ( )
   if 9 - 9: I1I11I1I1I
def oooooOOO000Oo ( ) :
 if 52 - 52: i1 % i11I1IIiiIi . Oo * ii1I
 import time
 if 50 - 50: iiIiIiIi - oOo * i11I1IIiiIi . iiI1i1
 try :
  Ii1iI = xbmcgui . DialogProgress ( )
  Ii1iI . create ( "ITV Wizard" , "Retrieving backup file... " , '' , 'Please wait' )
  o00oo0 = xbmc . translatePath ( os . path . join ( i1iiIII111ii , 'backup.zip' ) )
  I11ii1IIiIi = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  Ii1iI . update ( 0 , "" , "Installing..." )
  extract . all ( o00oo0 , I11ii1IIiIi , Ii1iI )
  Ii1iI . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( "ITV Wizard" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 37 - 37: iiIiIiIi % i11iIiiIii % i1 . iiI . I1I11I1I1I
 except :
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( 'ITV Wizard' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 51 - 51: iIIIiiIIiiiIi - iiI % Ooo0OO0oOO - i1
  if 31 - 31: OooO0OO / i1oOo0OoO - OooO0OO - Ii
  if 7 - 7: OooO0OO % iiI . Oo + o0 - Oo0o
def ii ( name , url , mode , iconimage , fanart , description ) :
 o0o0O00oo0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 Ii1ii1IiIII = True
 ooO0o = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ooO0o . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ooO0o . setProperty ( "Fanart_Image" , fanart )
 Ii1ii1IiIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0o0O00oo0 , listitem = ooO0o , isFolder = False )
 return Ii1ii1IiIII
 if 51 - 51: i11I1IIiiIi
def I1Ii1iI1 ( name , url , mode , iconimage , fanart , description ) :
 o0o0O00oo0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 Ii1ii1IiIII = True
 ooO0o = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ooO0o . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ooO0o . setProperty ( "Fanart_Image" , fanart )
 Ii1ii1IiIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0o0O00oo0 , listitem = ooO0o , isFolder = True )
 return Ii1ii1IiIII
 if 25 - 25: iII111iiiii11 + i11I1IIiiIi * iiI1i1
 if 92 - 92: o0 + Oo0o + iiI / Ii11111i + oOo
 if 18 - 18: iiIiIiIi * Oo . OooO0OO / iiI1i1 / i11iIiiIii
def IIIII ( ) :
 o0ooOoO000oO = [ ]
 OOo = sys . argv [ 2 ]
 if len ( OOo ) >= 2 :
  i1i11I1I1iii1 = sys . argv [ 2 ]
  I1iii11 = i1i11I1I1iii1 . replace ( '?' , '' )
  if ( i1i11I1I1iii1 [ len ( i1i11I1I1iii1 ) - 1 ] == '/' ) :
   i1i11I1I1iii1 = i1i11I1I1iii1 [ 0 : len ( i1i11I1I1iii1 ) - 2 ]
  ooo0OiII1iii = I1iii11 . split ( '&' )
  o0ooOoO000oO = { }
  for i11i1iiiII in range ( len ( ooo0OiII1iii ) ) :
   ooOO0oO0oo00o = { }
   ooOO0oO0oo00o = ooo0OiII1iii [ i11i1iiiII ] . split ( '=' )
   if ( len ( ooOO0oO0oo00o ) ) == 2 :
    o0ooOoO000oO [ ooOO0oO0oo00o [ 0 ] ] = ooOO0oO0oo00o [ 1 ]
    if 83 - 83: Ooo0OO0oOO - i1 - OooO0OO
 return o0ooOoO000oO
 if 3 - 3: oOo
 if 45 - 45: oOo
i1i11I1I1iii1 = IIIII ( )
oOIIi1iiii1iI = None
iiIoO = None
iIiiii = None
O0000OOO0 = None
ooo0 = None
oO000oOo00o0o = None
if 85 - 85: OooO0OO + iII111iiiii11 * OooO0OO - oOo % i11iIiiIii
if 71 - 71: iiI1i1 - iiIiIiIi / Oo * Oo / I1IiiI . I1IiiI
try :
 oOIIi1iiii1iI = urllib . unquote_plus ( i1i11I1I1iii1 [ "url" ] )
except :
 pass
try :
 iiIoO = urllib . unquote_plus ( i1i11I1I1iii1 [ "name" ] )
except :
 pass
try :
 O0000OOO0 = urllib . unquote_plus ( i1i11I1I1iii1 [ "iconimage" ] )
except :
 pass
try :
 iIiiii = int ( i1i11I1I1iii1 [ "mode" ] )
except :
 pass
try :
 ooo0 = urllib . unquote_plus ( i1i11I1I1iii1 [ "fanart" ] )
except :
 pass
try :
 oO000oOo00o0o = urllib . unquote_plus ( i1i11I1I1iii1 [ "description" ] )
except :
 pass
 if 53 - 53: oOo
 if 21 - 21: Oo0o
print str ( IiIIIiI1I1 ) + ': ' + str ( iiiIi )
print "Mode: " + str ( iIiiii )
print "URL: " + str ( oOIIi1iiii1iI )
print "Name: " + str ( iiIoO )
print "IconImage: " + str ( O0000OOO0 )
if 92 - 92: i11iIiiIii / oOo - OooO0OO % iiIiIiIi * oOo + i1oOo0OoO
if 11 - 11: iII111iiiii11 . oOo
def oOo0O0o00o ( content , viewType ) :
 if 80 - 80: iII111iiiii11 - Ii * I1I11I1I1I * iiI1i1 / o0 / Ii
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if O0O0OO0O0O0 . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % O0O0OO0O0O0 . getSetting ( viewType ) )
  if 13 - 13: oOo * iiIiIiIi + i11iIiiIii * oOo - iiIiIiIi
  if 23 - 23: ii1I * I1IiiI % iII111iiiii11 * i11I1IIiiIi
if iIiiii == None or oOIIi1iiii1iI == None or len ( oOIIi1iiii1iI ) < 1 :
 iIiIIi1 ( )
 if 9 - 9: i11I1IIiiIi - i1 + iiI / ii1I / i11iIiiIii
elif iIiiii == 1 :
 II ( iiIoO , oOIIi1iiii1iI , oO000oOo00o0o )
 if 39 - 39: i11I1IIiiIi * i1oOo0OoO + ii1I - i11I1IIiiIi + Ii
elif iIiiii == 2 :
 Ii11Ii1I ( iiIoO , oOIIi1iiii1iI , oO000oOo00o0o )
 if 69 - 69: iiI
elif iIiiii == 3 :
 O0OOO ( )
 if 85 - 85: iiIiIiIi / iiI
elif iIiiii == 4 :
 oooooOOO000Oo ( )
 if 18 - 18: Ii11111i % iiI * iiI1i1
elif iIiiii == 5 :
 III1iII1I1ii ( )
 if 62 - 62: oOo . i11I1IIiiIi . iII111iiiii11
elif iIiiii == 6 :
 oo0 ( iiIoO , oOIIi1iiii1iI , oO000oOo00o0o )
 if 11 - 11: Ii / Oo0o
elif iIiiii == 7 :
 o00oOOooOOo0o ( )
 if 73 - 73: I1IiiI / i11iIiiIii
elif iIiiii == 8 :
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR yellow]Important![/COLOR]" , "" , "Please POWER DOWN your Infinity TV, and then turn it back ON for the changes to take place." )
 xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
 if 58 - 58: i1oOo0OoO . i1 + Ooo0OO0oOO - i11iIiiIii / i1 / iiI
elif iIiiii == 9 :
 o0iI11I1II ( iiIoO , oOIIi1iiii1iI , oO000oOo00o0o )
 if 85 - 85: Oo + Ii
elif iIiiii == 10 :
 Oo0 ( iiIoO , oOIIi1iiii1iI , oO000oOo00o0o )
 if 10 - 10: i11I1IIiiIi / iIIIiiIIiiiIi + Oo / I1IiiI
 if 27 - 27: I1I11I1I1I
 if 67 - 67: o0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 55 - 55: iiI1i1 - OooO0OO * Ii11111i + Oo * Oo * iiI
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
