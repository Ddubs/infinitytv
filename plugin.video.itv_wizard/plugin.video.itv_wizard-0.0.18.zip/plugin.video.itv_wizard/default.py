import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import sys,plugintools
import zipfile

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
base='http://infinitytv.ca/downloads/'
ADDON=xbmcaddon.Addon(id='plugin.video.itv_wizard')

#########################################################################################################################################################

full_restore_link = 'http://infinitytv.ca/downloads/full_restore.zip'
adult_full_restore_link = 'http://infinitytv.ca/downloads/adult_full_restore.zip'
update_link =       'http://infinitytv.ca/downloads/update.zip'
support_name =      '[COLOR blue]Name: [/COLOR]Infinity TV'
support_website =   '[COLOR blue]Website: [/COLOR]www.infinitytv.ca'
support_full =      '[COLOR blue]Last full restore release :[/COLOR] Dec 15'
support_update =    '[COLOR blue]Last update release :[/COLOR] Aug 7'
support_facebook =  '[COLOR blue]Facebook:[/COLOR] facebook.com/myinfinitytv'

#########################################################################################################################################################

zip          =  ADDON.getSetting('zip')
dialog       =  xbmcgui.Dialog()
dp           =  xbmcgui.DialogProgress()
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA   =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons'))
GUI          =  xbmc.translatePath(os.path.join(USERDATA,'guisettings.xml'))
FAVS         =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
SOURCE       =  xbmc.translatePath(os.path.join(USERDATA,'sources.xml'))
ADVANCED     =  xbmc.translatePath(os.path.join(USERDATA,'advancedsettings.xml'))
RSS          =  xbmc.translatePath(os.path.join(USERDATA,'RssFeeds.xml'))
KEYMAPS      =  xbmc.translatePath(os.path.join(USERDATA,'keymaps','keyboard.xml'))
USB          =  xbmc.translatePath(os.path.join(zip))
skin         =  xbmc.getSkinDir()
HOME         =  xbmc.translatePath('special://home/')
TribecaUrl   =  'http://tribeca.tvaddons.ag/'
infinitypath  =  xbmc.translatePath(os.path.join('special://home','addons','plugin.video.itv_wizard'))
skinspath  =  xbmc.translatePath(os.path.join('special://home','addons','plugin.video.itv_wizard','resources','skins'))
    
VERSION = "0.0.11"
PATH = "itv_wizard"

#########################################################################################################################################################

AddonID='plugin.video.itv_wizard'; AddonTitle="Total Wipe"
EXCLUDES=  ['plugin.video.itv_wizard','skin.infinitytv']

def _get_keyboard( default="", heading="", hidden=False ):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard( default, heading, hidden )
    keyboard.doModal()
    if ( keyboard.isConfirmed() ):
        return unicode( keyboard.getText(), "utf-8" )
    return default

def ARCHIVE_CB(sourcefile, destfile, message_header, message1, message2, message3, exclude_dirs, exclude_files):
    zipobj = zipfile.ZipFile(destfile , 'w', zipfile.ZIP_DEFLATED)
    rootlen = len(sourcefile)
    for_progress = []
    ITEM =[]
    dp.create(message_header, message1, message2, message3)
    for base, dirs, files in os.walk(sourcefile):
        for file in files:
            ITEM.append(file)
    N_ITEM =len(ITEM)
    for base, dirs, files in os.walk(sourcefile):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        files[:] = [f for f in files if f not in exclude_files]
        for file in files:
            for_progress.append(file) 
            progress = len(for_progress) / float(N_ITEM) * 100  
            dp.update(int(progress),"Backing up...",'[COLOR yellow]%s[/COLOR]'%file, 'Please wait')
            fn = os.path.join(base, file)
            if not 'temp' in dirs:
                if not 'plugin.video.itv_wizard' in dirs:
                   import time
                   FORCE= '01/01/1980'
                   FILE_DATE=time.strftime('%d/%m/%Y', time.gmtime(os.path.getmtime(fn)))
                   if FILE_DATE > FORCE:
                       zipobj.write(fn, fn[rootlen:])  
    zipobj.close()
    dp.close()

def WipeXBMC(name,url,description):
    choice = xbmcgui.Dialog().yesno("[COLOR red]VERY IMPORTANT: [/COLOR]", 'This will completely wipe your infinity tv box settings.', 'Would you like to create a backup before proceeding?', '', yeslabel='Yes',nolabel='No')
    if choice == 1:
        title = urllib.quote_plus("backup")
        backup_zip = xbmc.translatePath(os.path.join(infinitypath,title+'.zip'))
        exclude_dirs_full =  ['plugin.video.itv_wizard','Thumbnails']
        exclude_files_full = ["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf','Textures13.db']
        message_header = "Creating backup... "
        message1 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
        message2 = ""
        message3 = "Please wait"
        ARCHIVE_CB(HOME, backup_zip, message_header, message1, message2, message3, exclude_dirs_full, exclude_files_full)
            
    '''if skin!= "skin.confluence":
        dialog.ok('[B]itv wizard[/B]','[COLOR yellow]NOTICE: [/COLOR]You must switch to the Confluence skin to wipe. ','Please change to Confluence and try wiping again.','')
        xbmc.executebuiltin("ActivateWindow(appearancesettings)")
        return'''
    
    choice2 = xbmcgui.Dialog().yesno("[COLOR red]FINAL WARNING!!! [/COLOR]", 'Are you absolutely certain about wiping your infinity tv box settings?', '', 'All addons and userdata will be gone!', yeslabel='Yes',nolabel='No')
    if choice2 == 0:
        return
    elif choice2 == 1:
        dp.create("[B]itv wizard[/B]","Wiping infinity tv Device...",'', 'Please wait')
        try:
            for root, dirs, files in os.walk(HOME,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try:
                        os.remove(os.path.join(root,name))
                        os.rmdir(os.path.join(root,name))
                    except: pass
                        
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
                    except: pass
        except: pass
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    dialog.ok('[B]itv wizard[/B]','Wipe complete! Please restart infinity tv box for changes to take effect.','','')
    return wizard(name,url,description)

def REMOVE_EMPTY_FOLDERS():
    print"########### Start Removing Empty Folders #########"
    empty_count = 0
    used_count = 0
    for curdir, subdirs, files in os.walk(HOME):
        if len(subdirs) == 0 and len(files) == 0: #check for empty directories. len(files) == 0 may be overkill
            empty_count += 1 #increment empty_count
            os.rmdir(curdir) #delete the directory
            print "successfully removed: "+curdir
        elif len(subdirs) > 0 and len(files) > 0: #check for used directories
            used_count += 1 #increment used_count

def backup_tool():
    choice = xbmcgui.Dialog().yesno("[COLOR yellow]itv wizard: [/COLOR]", 'Would you like to create a backup?.', 'Backup file will be stored in the plugin.video.itv_wizard folder.', '', yeslabel='Yes',nolabel='No')
    if choice == 1:
        title = urllib.quote_plus("backup")
        backup_zip = xbmc.translatePath(os.path.join(infinitypath,title+'.zip'))
        exclude_dirs_full =  ['plugin.video.itv_wizard','Thumbnails']
        exclude_files_full = ["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf','Textures13.db']
        message_header = "Creating backup... "
        message1 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
        message2 = ""
        message3 = "Please wait"
        ARCHIVE_CB(HOME, backup_zip, message_header, message1, message2, message3, exclude_dirs_full, exclude_files_full)
        dialog.ok('[B]itv wizard[/B]','Backup complete!','','')
    else:
        return

def Supportpopup():
    dialog.ok('[B]Infinity tv info[/B]',support_name,support_website,support_facebook+'[CR]'+support_full+'[CR]'+support_update)


#########################################################################################################################################################
wipe_icon = xbmc.translatePath(os.path.join(skinspath,'wipe.png'))
support_icon = xbmc.translatePath(os.path.join(skinspath,'support.png'))
fanart_background = xbmc.translatePath(os.path.join(skinspath,'fanart.jpg'))
restore_icon = xbmc.translatePath(os.path.join(skinspath,'restore.png'))
backup_icon = xbmc.translatePath(os.path.join(skinspath,'backup.png'))
fullrestore_icon = xbmc.translatePath(os.path.join(skinspath,'full_restore.png'))
adultfullrestore_icon = xbmc.translatePath(os.path.join(skinspath,'adult_full_restore.png'))
update_icon = xbmc.translatePath(os.path.join(skinspath,'updates.png'))
restore_backup_icon = xbmc.translatePath(os.path.join(skinspath,'restore_backup.png'))
    
def CATEGORIES():
    #link = OPEN_URL('https://raw.githubusercontent.com/Ddubs/infinitytv/master/plugin.video.itv_wizard/wizard_files/links.txt').replace('\n','').replace('\r','')
    #match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    #for name,url,iconimage,fanart,description in match:
    #    addDir(name,url,1,iconimage,fanart,description)
    addDir('Support Info',update_link,3,support_icon,fanart_background,'Support info from your TV box seller. ')
    addDir('Update',update_link,1,update_icon,fanart_background,'Update your box')
    addDir('Full Restore',full_restore_link,6,fullrestore_icon,fanart_background,'All addons and userdata will be completely wiped!')
    addDir('Adult Full Restore',adult_full_restore_link,6,adultfullrestore_icon,fanart_background,'All addons and userdata will be completely wiped!')
    #addDir('Complete wipe',update_link,2,wipe_icon,fanart_background,'All addons and userdata will be completely wiped!')
    #addDir('Backup',update_link,5,backup_icon,fanart_background,'Backup your build ')
    #addDir('Restore backup',update_link,4,restore_backup_icon,fanart_background,'Restore your backup from complete wipe. ')
    setView('movies', 'MAIN')
        
    
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
      
def wizard(name,url,description):
    
    path = xbmc.translatePath(os.path.join('special://home/addons','plugin.video.itv_wizard'))
    dp = xbmcgui.DialogProgress()
    dp.create("ITV Wizard","Downloading... ",'', 'Please wait')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    #READ_ZIP(lib)
    time.sleep(2)
    dp.update(0,"", "Installing...")
    extract.all(lib,addonfolder,dp)
    dp.update(0,"", "Finishing up...")
    time.sleep(5)
    #xbmc.executebuiltin('UnloadSkin()')
    #time.sleep(2)
    #xbmc.executebuiltin('ReloadSkin()')
    #time.sleep(2)
    dialog = xbmcgui.Dialog()
    dialog.ok("ITV Wizard", "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]")
    dialog = xbmcgui.Dialog()
    dialog.ok("ITV Wizard", "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]")


def Full_Wizard(name,url,description):
    dp = xbmcgui.DialogProgress()
    #choice = xbmcgui.Dialog().yesno("[COLOR red]VERY IMPORTANT: [/COLOR]", 'This will completely wipe your infinity tv box settings.', 'Would you like to create a backup before proceeding?', '', yeslabel='Yes',nolabel='No')
    #if choice == 1:
    #    title = urllib.quote_plus("backup")
    #    backup_zip = xbmc.translatePath(os.path.join(infinitypath,title+'.zip'))
    #    exclude_dirs_full =  ['plugin.video.itv_wizard','Thumbnails']
    #    exclude_files_full = ["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf','Textures13.db']
    #    message_header = "Creating backup... "
    #    message1 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
    #    message2 = ""
    #    message3 = "Please wait"
    #    ARCHIVE_CB(HOME, backup_zip, message_header, message1, message2, message3, exclude_dirs_full, exclude_files_full)
                
    choice2 = xbmcgui.Dialog().yesno("[COLOR red]WARNING!!! [/COLOR]", 'By pressing YES you will wipe all your current settings ', '', 'and restore your Infinity TV to its latest complete build.', yeslabel='Yes',nolabel='No')
    if choice2 == 0:
        return
    elif choice2 == 1:
        dp.create("[B]itv wizard[/B]","Wiping infinity tv device...",'', 'Please wait as it will take a few minutes')
        try:
            for root, dirs, files in os.walk(HOME,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try:
                        os.remove(os.path.join(root,name))
                        os.rmdir(os.path.join(root,name))
                    except: pass
                        
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
                    except: pass
        except: pass
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    dialog = xbmcgui.Dialog()
    dialog.ok('[B]itv wizard[/B]','Wipe complete! Please press ok to download the restore files.','','')
    path = xbmc.translatePath(os.path.join('special://home/addons','plugin.video.itv_wizard'))
    dp = xbmcgui.DialogProgress()
    dp.create("ITV Wizard","Downloading... ",'', 'Please wait')
    
    lib=os.path.join(path, 'fullbackup.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Installing...")
    extract.all(lib,addonfolder,dp)
    dp.update(0,"", "Finishing up...")
    time.sleep(5)
    dialog = xbmcgui.Dialog()
    dialog.ok("ITV Wizard", "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]")
    dialog = xbmcgui.Dialog()
    dialog.ok("ITV Wizard", "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]")

    
def READ_ZIP(url):

    import zipfile
    
    z = zipfile.ZipFile(url, "r")
    for filename in z.namelist():
        if 'guisettings.xml' in filename:
            a = z.read(filename)
            r='<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>'% skin
            
            match=re.compile(r).findall(a)
            print match
            for type,string,setting in match:
                setting=setting.replace('&quot;','') .replace('&amp;','&') 
                xbmc.executebuiltin("Skin.Set%s(%s,%s)"%(type.title(),string,setting))  
                
        if 'favourites.xml' in filename:
            a = z.read(filename)
            f = open(FAVS, mode='w')
            f.write(a)
            f.close()  
			               
        if 'sources.xml' in filename:
            a = z.read(filename)
            f = open(SOURCE, mode='w')
            f.write(a)
            f.close()    
                         
        if 'advancedsettings.xml' in filename:
            a = z.read(filename)
            f = open(ADVANCED, mode='w')
            f.write(a)
            f.close()                 

        if 'RssFeeds.xml' in filename:
            a = z.read(filename)
            f = open(RSS, mode='w')
            f.write(a)
            f.close()                 
            
        if 'keyboard.xml' in filename:
            a = z.read(filename)
            f = open(KEYMAPS, mode='w')
            f.write(a)
            f.close()

def RESTORE():

    import time
        
    try:
        dp = xbmcgui.DialogProgress()
        dp.create("ITV Wizard","Retrieving backup file... ",'', 'Please wait')
        lib=xbmc.translatePath(os.path.join(infinitypath,'backup.zip'))
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        dp.update(0,"", "Installing...")
        extract.all(lib,addonfolder,dp)
        dp.update(0,"", "Finishing up...")
        time.sleep(5)
        dialog = xbmcgui.Dialog()
        dialog.ok("ITV Wizard", "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]")
        dialog = xbmcgui.Dialog()
        dialog.ok("ITV Wizard", "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]")
        
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok('ITV Wizard','You need to backup your build first.\nTo backup your box press backup on main menu.','','')



def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        CATEGORIES()
       
elif mode==1:
        wizard(name,url,description)

elif mode==2:
        WipeXBMC(name,url,description)

elif mode==3:
        Supportpopup()

elif mode==4:
        RESTORE()

elif mode==5:
        backup_tool()

elif mode==6:
        Full_Wizard(name,url,description)
        

        
xbmcplugin.endOfDirectory(int(sys.argv[1]))

