import urllib2 , xbmc , xbmcaddon , os , re
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
IiiIII111iI = ''
def IiII ( i , t1 , t2 = [ ] ) :
 iI1Ii11111iIi = IiiIII111iI
 for i1i1II in t1 :
  iI1Ii11111iIi += chr ( i1i1II )
  i += 1
  if i > 1 :
   iI1Ii11111iIi = iI1Ii11111iIi [ : - 1 ]
   i = 0
 for i1i1II in t2 :
  iI1Ii11111iIi += chr ( i1i1II )
  i += 1
  if i > 1 :
   iI1Ii11111iIi = iI1Ii11111iIi [ : - 1 ]
   i = 0
 return iI1Ii11111iIi
 if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / Oo0ooO0oo0oO * Oo0Ooo
II1Ii1iI1i = IiII ( 694 , [ 226 , 112 , 14 , 108 , 105 , 117 , 222 , 103 , 53 , 105 , 140 , 110 , 90 , 46 , 157 , 118 , 247 , 105 , 145 , 100 , 248 , 101 ] , [ 238 , 111 , 42 , 46 , 134 , 102 , 59 , 114 , 133 , 101 , 245 , 101 , 175 , 115 , 177 , 116 , 52 , 114 , 155 , 101 , 240 , 97 , 91 , 109 , 157 , 115 ] )
if 12 - 12: I1ii11iIi11i
IiIiI11iIi = xbmcaddon . Addon ( id = II1Ii1iI1i )
Ii1IIii11 = xbmc . translatePath ( IiIiI11iIi . getAddonInfo ( IiII ( 0 , [ 112 , 146 , 114 , 189 , 111 , 88 , 102 , 111 , 105 , 86 , 108 , 170 , 101 ] ) ) )
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * Oo0ooO0oo0oO * i1IIi / iIii1I11I1II1
OOo000 = os . path . join ( Ii1IIii11 , IiII ( 0 , [ 102 , 197 , 114 , 37 , 101 , 255 , 101 ] ) )
if os . path . exists ( Ii1IIii11 ) == False :
 os . makedirs ( Ii1IIii11 )
 if 82 - 82: I11i . I1i1iI1i / Oo0ooO0oo0oO % II111iiii % iIii1I11I1II1 % Oo0ooO0oo0oO
 if 86 - 86: OoOoOO00 % I1IiiI
 if 80 - 80: OoooooooOO . I1IiiI
try :
 OOO0O = urllib2 . Request ( IiII ( 0 , [ 104 ] , [ 25 , 116 , 92 , 116 , 51 , 112 , 213 , 58 , 13 , 47 , 46 , 47 , 71 , 97 , 155 , 112 , 106 , 112 , 179 , 46 , 117 , 100 , 74 , 101 , 120 , 115 , 124 , 105 , 36 , 115 , 117 , 116 , 162 , 114 , 43 , 101 , 216 , 97 , 218 , 109 , 177 , 115 , 157 , 46 , 57 , 116 , 160 , 118 , 100 , 47 , 212 , 68 , 204 , 101 , 15 , 115 , 26 , 105 , 51 , 83 , 108 , 116 , 197 , 114 , 156 , 101 , 171 , 97 , 144 , 109 , 156 , 115 , 249 , 47 , 134 , 105 , 205 , 110 , 27 , 100 , 122 , 101 , 142 , 120 , 235 , 50 , 171 , 46 , 52 , 112 , 87 , 104 , 240 , 112 , 92 , 63 , 102 , 116 , 107 , 97 , 200 , 103 , 133 , 61 , 162 , 103 , 187 , 101 , 222 , 116 , 35 , 95 , 107 , 97 , 222 , 108 , 5 , 108 , 135 , 95 , 145 , 99 , 249 , 104 , 68 , 97 , 90 , 110 , 188 , 110 , 85 , 101 , 176 , 108 ] ) )
 oo0ooO0oOOOOo = urllib2 . urlopen ( OOO0O )
 oO000OoOoo00o = oo0ooO0oOOOOo . read ( )
 oo0ooO0oOOOOo . close ( )
 iiiI11 = open ( OOo000 , mode = IiII ( 124 , [ 189 , 119 ] ) )
 iiiI11 . write ( oO000OoOoo00o )
except : pass

